<?php
$pesan = mysql_query("SELECT * FROM contact ORDER BY id DESC;") or die (mysql_error());
?>
<div class="row animated fadeInUp">
    
    <div class="col-sm-12">
    
        <h1 class="page-header alert alert-success">Selamat Datang <?php echo $_SESSION["administrator_fullname"]?>. ID Admin (<?php echo $_SESSION["administrator_id"]?>)</h1>
    
    </div>
</div>
<style>
    .huge{
        font-size: 50px;
    }
</style>
<div class="row fadeInUp animated">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-book fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                    <?php
                                    $biologi = mysql_query("SELECT * FROM istilahbiologi") or die(mysql_error());
                                    echo mysql_num_rows($biologi);
                                    ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left"><strong>Istilah Biologi</strong></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-success">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-leaf fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                        <?php
                                    $flora = mysql_query("SELECT * FROM floraindo") or die(mysql_error());
                                    echo mysql_num_rows($flora);
                                    ?>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left"><strong>Flora Indonesia</strong></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-info">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-stethoscope fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                        <?php
                                    $medis = mysql_query("SELECT * FROM istilahpentingmedis") or die(mysql_error());
                                    echo mysql_num_rows($medis);
                                    ?>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left"><strong>Istilah Medis</strong></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>

                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-warning">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-3">
                                    <i class="fa fa-medkit fa-5x"></i>
                                </div>
                                <div class="col-xs-9 text-right">
                                    <div class="huge">
                                    <?php
                                    $vitamin = mysql_query("SELECT * FROM vitamin") or die(mysql_error());
                                    echo mysql_num_rows($vitamin);
                                    ?>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left"><strong>Data Vitamin</strong></span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
<br>
<div class="panel panel-primary animated fadeInUp">
    <div class="panel-heading"><strong class="text-default">Notifikasi Pesan</strong></div>
    <div class="panel-body">
        <!-- <div class="table-responsive"> -->
            <table width="100%" class="table table-striped table-condensed table-bordered table-hover" id="tabel-biologi">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Email</th>
                        <th>Pesan</th>
                        <th>Datetime</th>
                        <th>Aksi</th>
                    </tr>
                </thead>         
                <tbody>
                <?php if (mysql_num_rows($pesan) > 0) { $no = 1 ?>
                    <?php while ($row_pesan = mysql_fetch_array($pesan)) { ?>
                    <?php 
                          if (($no % 2) == 0) {
                              $class_background = "active";
                           } else {
                              $class_background = "info";
                           }         
                    ?>
                    <tr class="<?php echo $class_background ?>">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_pesan['name']?></td>
                        <td><?php echo $row_pesan['email']?></td>
                        <td><?php echo $row_pesan['message']?></td>
                        <td><?php echo $row_pesan['datetime']?></td>
                        <td class="center"><a  href="index.php?pesan-delete=<?php echo $row_pesan["id"]; ?>" onclick="javascript: return confirm('Apakah Anda yakin akan menghapus pesan ini ?')" class="glyphicon glyphicon-trash" type="button" title="Hapus"></a></td>
                    </tr>
                        <?php $no++ ?>
                    <?php } ?>
                <?php } else { ?>
                </tbody>
                <div class="alert alert-danger fade in"> <span class="fa fa-info-circle fa-fw"></span><button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button> Tidak ada pesan </div>
                    <?php }?>
            </table>
        </div>
    </div>
<!-- </div> -->

