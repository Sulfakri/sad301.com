<?php
if (empty($_SESSION["administrator_id"])) header("location:login.php");
$lihat_admin = mysql_query("SELECT * FROM administrator ORDER BY fullname ASC;") or die(mysql_error());

if (isset($_POST["tambah_admin"])) {
    $username = mysql_real_escape_string(trim($_POST["username"]));
    $password = mysql_real_escape_string(md5($_POST["password"]));
    $fullname = mysql_real_escape_string(trim($_POST["fullname"]));
    $email = mysql_real_escape_string(trim($_POST["email"]));

    // $nama_gambar  = $_FILES['foto']['name'];
    // $sumber = $_FILES['foto']['tmp_name'];
    // $target = '../images/admin/';

    // $sql_cek_user = mysql_query("SELECT * FROM administrator WHERE username='$username'") or die (mysql_error());
    // if (mysql_num_rows($sql_cek_user)>0) {
    //   echo "<script>alert('Username yang Anda pilih sudah ada, silahkan ganti yang lain');</script>";
    // } else {
    //   if ($nama_gambar !='') {
    //     if (move_uploaded_file($sumber, $target.$nama_gambar)) {
    //       mysql_query("INSERT INTO administrator VALUES ('','$username','$password','$fullname','$email','$nama_gambar');") or die(mysql_error());
    //       header("location:index.php?profil-admin");
    //     }
    //   } else {
        mysql_query("INSERT INTO administrator VALUES ('','$username','$password','$fullname','$email');") or die(mysql_error());
        header("location:index.php?profil-admin");
      }
  //   }
  // }

?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Profil Admin</h3>
    </div>
</div>

<!--Input Data Baru-->
    <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-hidden="true">
       <div class="modal-dialog">
         <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><p class="text-success"><strong>Tambah Data</strong></p></h4>
                </div>
                    <div class="modal-body">
                        <form role="form" action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Username</label>
                                <input class="form-control" required="required" type="text" name="username" required />
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input class="form-control" type="password" name="password" required />
                            </div>
                            <div class="form-group">
                               <label>Fullname</label>
                               <input class="form-control" type="text" name="fullname" required />
                            </div>
                            <div class="form-group">
                               <label>Email</label>
                               <input class="form-control" type="email" name="email" required />
                            </div> 
<!--                             <div class="form-group">
                              <label>Foto</label>
                              <input type="file" value="Foto" name="foto"> 
                            </div> -->
                            <button type="submit" name="tambah_admin" class="btn btn-primary btn-primary"><span class="fa fa-plus-square"></span> Simpan</button>
                            &nbsp;
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>  Tutup</button>
                    </div>
            </div>
       </div>
    </div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                List Data 
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-condensed table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Username</th>
                        <th>Password</th>
                        <th>Fullname</th>
                        <th>Email</th>
                        <!-- <th>Foto</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($lihat_admin) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_admin = mysql_fetch_array($lihat_admin)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "active";
                           } else {
                              $class_background = "success";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?>">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_admin["username"]; ?></td>
                        <td><?php echo $row_admin["password"]; ?></td>
                        <td><?php echo $row_admin["fullname"]; ?></td>
                        <td><?php echo $row_admin["email"]; ?></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } else { ?>
                    </tbody>
                        <div class="alert alert-danger fade in"> <span class="fa fa-info-circle fa-fw"></span>
                      <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                      Data kosong </div>
                    <?php } ?>
                  </table>
                </div>
            </div>
        </div>
      <p class="pull-right"><a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#tambahData"> <i class="fa fa-plus"></i> Admin</a></p>
    </div>
</div>