<?php

if (empty($_SESSION["administrator_id"])) header("location:login.php");
$sql_flora = mysql_query("SELECT * FROM floraindo ORDER BY nama_tumbuhan ASC;") or die(mysql_error());

if (isset($_POST["submit_save_flora"])) {
    $nama_tumbuhan = mysql_real_escape_string(trim(ucfirst($_POST["nama_tumbuhan"])));
    $unsur_obat = mysql_real_escape_string(trim(ucfirst($_POST["unsur_obat"])));
    $khasiat = mysql_real_escape_string(trim(ucfirst($_POST["khasiat"])));
    $sql_in = mysql_query("INSERT INTO floraindo VALUES ('','$nama_tumbuhan','$unsur_obat','$khasiat');") or die(mysql_error());
    header("location:index.php?flora-obat");
}
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Data Tumbuhan Flora</h3>
    </div>
</div>
<p class="text-danger"><a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#tambahFlora"> <i class="fa fa-plus"></i> Data Baru</a></p>
&nbsp;&nbsp;
<!--Input Data Baru-->
    <div class="modal fade" id="tambahFlora" tabindex="-1" role="dialog" aria-hidden="true">
       <div class="modal-dialog">
         <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><p class="text-success"><strong>Tambah Data</strong></p></h4>
                </div>
                    <div class="modal-body">
                        <form role="form" action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Nama Tumbuhan</label>
                                <input class="form-control" required="required" type="text" name="nama_tumbuhan" />
                            </div>
                            <div class="form-group">
                                <label>Unsur Obat</label>
                                <input class="form-control" type="text" name="unsur_obat" required />
                            </div>
                            <div class="form-group">
                               <label>Khasiat</label>
                               <textarea class="form-control" name="khasiat"></textarea>
                            </div>
                            <button type="submit" name="submit_save_flora" class="btn btn-primary btn-primary"><span class="fa fa-plus-square"></span> Simpan</button>
                            &nbsp;
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>  Tutup</button>
                    </div>
            </div>
       </div>
    </div>

<div class="row">
    <div class="col-md-12 col-lg-12 col-xs-12">
        <div class="panel panel-danger">
            <div class="panel-heading">
                List Data 
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-condensed table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Unsur Obat</th>
                        <th>Khasiat</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($sql_flora) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_flora = mysql_fetch_array($sql_flora)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "danger";
                           } else {
                              $class_background = "success";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?> ">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_flora["nama_tumbuhan"]; ?></td>
                        <td><?php echo $row_flora["unsur_obat"]; ?></td>
                        <td><?php echo $row_flora["khasiat"]; ?></td>
                        <td class="center">
                        <a href="index.php?update-flora=<?php echo $row_flora["id"]; ?>" class="glyphicon glyphicon-edit" type="button" title="Edit"></a> &nbsp;&nbsp; 
                        <a href="index.php?delete-flora=<?php echo $row_flora["id"]; ?>" onclick="javascript: return confirm('Apakah Anda Yakin akan Menghapus Data Ini ?')" class="glyphicon glyphicon-trash" type="button" title="Hapus"></a></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } else { ?>
                    </tbody>
                        <div class="alert alert-danger fade in"> <span class="fa fa-info-circle fa-fw"></span>
                      <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                      Data kosong </div>
                    <?php } ?>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>


