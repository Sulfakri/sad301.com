<?php

if (empty($_SESSION["administrator_id"])) header("location:login.php");
$sql_vitamin = mysql_query("SELECT * FROM vitamin ORDER BY namavitamin ASC;") or die(mysql_error());

if (isset($_POST["submit_save_vitamin"])) {
    $namavitamin = mysql_real_escape_string(trim(ucwords($_POST["namavitamin"])));
    $fungsi = mysql_real_escape_string(trim(ucfirst($_POST["fungsi"])));
    $kadar = mysql_real_escape_string(trim($_POST["kadar"]));
    $sumbermakanan = mysql_real_escape_string(trim(ucfirst($_POST["sumbermakanan"])));
    $sql_cek_nama_vit = mysql_query("SELECT * FROM vitamin WHERE namavitamin='$namavitamin'") or die(mysql_error());
    if (mysql_num_rows($sql_cek_nama_vit)>0) {
      echo "<script>alert('Nama vitamin sudah ada')</script>";
    }else {
    $sql_in = mysql_query("INSERT INTO vitamin VALUES ('','$namavitamin','$fungsi','$kadar','$sumbermakanan');") or die(mysql_error());
    header("location:index.php?vitamin");
  }
}
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Data Istilah Vitamin</h3> 
    </div>
</div>
<p><a href="#" class="btn btn-warning btn-sm" data-toggle="modal" data-target="#tambahDatavitamin"> <i class="fa fa-plus"></i> Data Baru</a></p>
<!--Input Data Baru-->
    <div class="modal fade" id="tambahDatavitamin" tabindex="-1" role="dialog" aria-hidden="true">
       <div class="modal-dialog">
         <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><p class="text-success"><strong>Tambah Data</strong></p></h4>
                </div>
                    <div class="modal-body">
                        <form role="form" action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Vitamin</label>
                                <input class="form-control" required="required" type="text" name="namavitamin" />
                            </div>
                            <div class="form-group">
                                <label>Fungsi</label>
                                <textarea class="form-control" type="text" name="fungsi" required></textarea>
                            </div>
                            <div class="form-group">
                                <label>Kadar</label>
                                <input class="form-control" type="text" name="kadar" required />
                            </div>
                            <div class="form-group">
                                <label>Sumber Makanan</label>
                                <textarea class="form-control" type="text" name="sumbermakanan" required ></textarea>
                            </div>
                            <button type="submit" name="submit_save_vitamin" class="btn btn-info"><span class="fa fa-plus-square"></span> Simpan</button>
                            &nbsp;
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>  Tutup</button>
                    </div>
            </div>
       </div>
    </div>

<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-success">
            <div class="panel-heading">
                <p class="text-success"><strong>List Data</strong></p> 
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>VIT</th>
                        <th>Fungsi</th>
                        <th>Kadar</th>
                        <th>Sumber Makanan</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($sql_vitamin) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_vitamin = mysql_fetch_array($sql_vitamin)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "success";
                           } else {
                              $class_background = "warning";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?> ">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_vitamin["namavitamin"]; ?></td>
                        <td><?php echo $row_vitamin["fungsi"]; ?></td>
                        <td><?php echo $row_vitamin["kadar"]; ?></td>
                        <td><?php echo $row_vitamin["sumbermakanan"]; ?></td>
                        <td class="center">
                        <a href="index.php?update-vitamin=<?php echo $row_vitamin["id"]; ?>" class="glyphicon glyphicon-edit" type="button" title="Edit"></a> &nbsp;&nbsp; 
                        <a href="index.php?delete-vitamin=<?php echo $row_vitamin["id"]; ?>" onclick="javascript: return confirm('Apakah Anda Yakin akan Menghapus Data Ini ?')" class="glyphicon glyphicon-trash" type="button" title="Hapus"></a></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } else { ?>
                    </tbody>
                        <div class="alert alert-danger fade in"> <span class="fa fa-info-circle fa-fw"></span>
                      <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                      Data kosong </div>
                    <?php } ?>
                  </table>
                </div>
            </div>
        </div>        
    </div>
</div>


