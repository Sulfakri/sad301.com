<?php
ob_start();
session_start();

require_once("config.php");
if (isset($_POST["submit_login"])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql_login_administrator = mysql_query("SELECT * FROM administrator WHERE username='$username' AND password='$password'") or die(mysql_error());

    if (mysql_num_rows($sql_login_administrator) > 0) {
        $row_administrator = mysql_fetch_array($sql_login_administrator);
        $_SESSION["administrator_id"] = $row_administrator["id"];
        $_SESSION["administrator_fullname"] = $row_administrator["fullname"];
        header("location:index.php?administrator");
    } else {
        header("location:login.php?failed");
    }
}

?>
<!DOCTYPE html>
<html>
<?php require_once("include/head.php") ?>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-4 col-md-offset-4">
                <div class="login-panel panel panel-default">
                    <div class="panel-heading">
                        <h3 class="panel-title">Administrator</h3>
                    </div>
                    <div class="panel-body">
                        <?php if (isset($_GET["failed"])) { ?>
                            <div class="alert alert-danger fade in">
                                <span class="fa fa-info-circle fa-fw"></span><button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                                Username atau Password Salah.
                            </div>
                        <?php } ?>
                        <form role="form" action="" method="post">
                            <fieldset>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Username" name="username" type="text" autofocus="autofocus" required="" />
                                </div>
                                <div class="form-group">
                                    <input class="form-control" placeholder="Password" name="password" type="password" value="" required="" />
                                </div>
                                <input type="submit" name="submit_login" value="Login" class="btn btn-lg btn-warning btn-block">
                                <a href="../index.php" class="btn btn-md btn-success btn-block" role="button">Cancel</a>
                            </fieldset>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
    <script src="js/sb-admin.js"></script>
</body>
</html>
<?php 
ob_end_flush(); 
?>