<?php
ob_start();
session_start();

require_once("config.php");

if (!isset($_SESSION["administrator_id"])) header("location:login.php");
?>
<!DOCTYPE html>
<html>
<?php require_once("include/head.php") ?>
<style type="text/css">
    .animated {
      -webkit-animation-duration: 1s;
      animation-duration: 1s;
      -webkit-animation-fill-mode: both;
      animation-fill-mode: both;
    }

    @-webkit-keyframes fadeInUp {
      0% {
        opacity: 0;
        -webkit-transform: translateY(10px);
        transform: translateY(10px);
      }
      100% {
        opacity: 1;
        -webkit-transform: translateY(0);
        transform: translateY(0);
      }
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        -webkit-transform: translateY(10px);
        -ms-transform: translateY(10px);
        transform: translateY(10px);
      }
      100% {
        opacity: 1;
        -webkit-transform: translateY(0);
        -ms-transform: translateY(0);
        transform: translateY(0);
      }
    }

    .fadeInUp {
      -webkit-animation-name: fadeInUp;
      animation-name: fadeInUp;
    }
        </style>
<body>
    <div id="wrapper">
        <?php require_once("include/header.php") ?>
        <div id="page-wrapper">
            <?php
            if (isset($_GET["crud-istilah"])) require_once("skrip/crud-istilah.php");
            else if (isset($_GET["istilah-update"])) require_once("skrip/update.php");
            else if (isset($_GET["istilah-delete"])) require_once("skrip/delete.php");
            else if (isset($_GET["update-flora"])) require_once("skrip/update-flora.php");
            else if (isset($_GET["delete-flora"])) require_once("skrip/delete-flora.php");
            else if (isset($_GET["pesan-delete"])) require_once("skrip/delete-pesan.php");
            else if (isset($_GET["istilah-medis"])) require_once("page/home/istilah-medis.php");
            else if (isset($_GET["delete-medis"])) require_once("skrip/delete-medis.php");
            else if (isset($_GET["update-medis"])) require_once("skrip/update-medis.php");
            else if (isset($_GET["flora-obat"])) require_once("page/home/flora-obat.php");
            else if (isset($_GET["vitamin"])) require_once("page/home/vitamin.php");
            else if (isset($_GET["update-vitamin"])) require_once("skrip/update-vitamin.php");
            else if (isset($_GET["delete-vitamin"])) require_once("skrip/delete-vitamin.php");
            else if (isset($_GET["profil-admin"])) require_once("page/home/profil-admin.php");
            else require_once("page/home/index.php");
            ?>
        </div>
    </div>
    <?php require_once("include/footer.php") ?>
</body>
</html>
<?php 
mysql_close($connection);
ob_end_flush(); 
?>