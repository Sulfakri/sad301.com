<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="Istilah Biologi">
    <title>Panel Admin KB</title>
    <link href="asset/icon.png" type="image/x-icon" rel="Shortcut Icon" />
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/editor/index.css" rel="stylesheet">
    <script type="text/javascript" src="js/ckeditor/ckeditor.js"></script>
	<script type="text/javascript" src="js/ckeditor/styles.js"></script>
    <script type="text/javascript" src="js/jquery.min.js"></script>
	<script type="text/javascript" src="js/up.js"></script>
    <!-- <link href="font-awesome/css/font-awesome.css" rel="stylesheet" /> -->
    <link href="css/sb-admin.css" rel="stylesheet" />

    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet">
    <link href="vendor/metisMenu/metisMenu.min.css" rel="stylesheet">
    <link href="vendor/datatables-plugins/dataTables.bootstrap.css" rel="stylesheet">
    <link href="vendor/datatables-responsive/dataTables.responsive.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
</head>
