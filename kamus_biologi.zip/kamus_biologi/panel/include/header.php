<nav class="navbar navbar-inverse navbar-fixed-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php"><p class="text-danger">aPanel Kamus Biologi v1.0</p></a>
    </div>
    <ul class="nav navbar-top-links navbar-right">
        <li class="dropdown">
            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
            </a>
            <ul class="dropdown-menu">
                <li><a onclick="javascript: return confirm('Anda yakin akan logout ?')" href="logout.php" target="new"><i class="fa fa-sign-out fa-fw"></i> Logout</a>
                </li>
            </ul>
        </li>
    </ul>
    <div class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li><a href="index.php"><i class="fa fa-dashboard fa-fw" aria-hidden="true"></i> Dashboard</a></li>
                <li>
                    <a href="#"><i class="fa fa-pencil-square-o" aria-hidden="true"></i> Edit <span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li><a href="index.php?crud-istilah"><i class="fa fa-book" aria-hidden="true"></i> Istilah Biologi</a></li>
                        <li><a href="index.php?istilah-medis"><i class="fa fa-medkit" aria-hidden="true"></i> Istilah Medis</a></li>
                        <li><a href="index.php?flora-obat"><i class="fa fa-leaf fa-fw"></i> Flora Indonesia sbg Obat</a></li>
                        <li><a href="index.php?vitamin"><i class="fa fa-flask" aria-hidden="true"></i> Vitamin</a></li>
                    </ul>
                </li>
                <li><a href="index.php?profil-admin"><i class="fa fa-user fa-fw"></i> Profil</a></li>
            </ul>
        </div>
    </div>
</nav>