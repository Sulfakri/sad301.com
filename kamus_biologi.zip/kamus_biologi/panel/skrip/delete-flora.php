<?php
if (isset($_GET["delete-flora"])) {
	$id = (int)mysql_real_escape_string(trim($_GET["delete-flora"]));
	mysql_query("DELETE FROM floraindo WHERE id = '$id';") or die (mysql_error());
}
header("location:index.php?flora-obat");