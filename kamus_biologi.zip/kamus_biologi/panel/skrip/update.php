<?php
if (isset($_POST["submit_update_istilah"])) {
    $id_istilah = mysql_escape_string(trim(ucfirst($_POST["id_istilah"])));
    $nama = mysql_escape_string(trim(ucfirst($_POST["nama"])));
    $detail = mysql_escape_string(trim($_POST["detail"]));
    $cat_huruf = mysql_real_escape_string($_POST["cat-h"]);
    date_default_timezone_set('Asia/Jakarta');
    $datetime = date("d-m-y H:i:s");
    $qry_upd = mysql_query("UPDATE istilahbiologi SET nama='$nama' , detail='$detail' ,cat_huruf='$cat_huruf', waktu='$datetime' WHERE id='$id_istilah';") or die(mysql_error());
    
    header("location:index.php?crud-istilah");
}
$id = abs((int)$_GET["istilah-update"]);
$sql_update_istilah = mysql_query("SELECT * FROM istilahbiologi WHERE id = '$id';") or die(mysql_error());
$row_upd = mysql_fetch_array($sql_update_istilah);

if (mysql_num_rows($sql_update_istilah)==0) header("location:index.php?crud-istilah");
if (isset($_POST["cancel_update"])) header("location:index.php?crud-istilah");
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Update &raquo; Istilah Biologi</h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Input Data
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form role="form" action="" enctype="multipart/form-data" method="post">
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" type="text" name="nama" value="<?php echo $row_upd["nama"] ?>" />
                            </div>
                            <div class="form-group">
                                <label>Detail</label>
                            <?php
                                echo"<textarea id='edit1' name='detail' class='form-control'>$row_upd[detail]</textarea>";
                            ?>
                            </div>
                            <div class="form-group">
                                <label>Cat. Huruf</label>
                                <select name="cat-h" class="form-control" style="width:80px;" required>
                                <?php echo "<option value='$row_upd[cat_huruf]'>$row_upd[cat_huruf]</option>" ?>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                                <option value="F">F</option>
                                <option value="G">G</option>
                                <option value="H">H</option>
                                <option value="I">I</option>
                                <option value="J">J</option>
                                <option value="K">K</option>
                                <option value="L">L</option>
                                <option value="M">M</option>
                                <option value="N">N</option>
                                <option value="O">O</option>
                                <option value="P">P</option>
                                <option value="Q">Q</option>
                                <option value="R">R</option>
                                <option value="S">S</option>
                                <option value="T">T</option>
                                <option value="U">U</option>
                                <option value="V">V</option>
                                <option value="W">W</option>
                                <option value="X">X</option>
                                <option value="Y">Y</option>
                                <option value="Z">Z</option> 
                                </select>
                            </div>
                            <button type="submit" name="submit_update_istilah" class="btn btn-success">Update</button>
                            <button type="submit" name="cancel_update" class="btn btn-warning">Cancel</button>
                            <input type="hidden" name="id_istilah" value="<?php echo $row_upd["id"] ?>">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    var editor = CKEDITOR.replace( 'edit1' ); 
</script>
