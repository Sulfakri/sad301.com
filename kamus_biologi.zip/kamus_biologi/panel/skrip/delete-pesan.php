<?php
if (isset($_GET["pesan-delete"])) {
	$id = (int)mysql_real_escape_string(trim($_GET["pesan-delete"]));
	mysql_query("DELETE FROM contact WHERE id = '$id';") or die (mysql_error());
}
header("location:index.php");