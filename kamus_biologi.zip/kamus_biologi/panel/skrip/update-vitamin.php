<?php
if (isset($_POST["submit_update_vitamin"])) {
    $id_vitamin = mysql_escape_string(trim($_POST["id_vitamin"]));
    $namavitamin = mysql_escape_string(trim(ucfirst($_POST["namavitamin"])));
    $fungsi = mysql_escape_string(trim(ucfirst($_POST["fungsi"])));
    $kadar = mysql_escape_string(trim($_POST["kadar"]));
    $sumbermakanan = mysql_escape_string(trim(ucfirst($_POST["sumbermakanan"])));

$qry_upd = mysql_query("UPDATE vitamin SET namavitamin='$namavitamin' , fungsi='$fungsi' , kadar='$kadar' , sumbermakanan='$sumbermakanan' WHERE id='$id_vitamin';") or die(mysql_error());
    
    header("location:index.php?vitamin");
}
$id = abs((int)$_GET["update-vitamin"]);
$sql_update_vitamin = mysql_query("SELECT * FROM vitamin WHERE id = '$id';") or die(mysql_error());
$row_update_vitamin = mysql_fetch_array($sql_update_vitamin);

if (mysql_num_rows($sql_update_vitamin)==0) header("location:index.php?vitamin");
if (isset($_POST["cancel_update"])) header("location:index.php?vitamin");
?>

<div class="row">
    <div class="col-lg-8">
        <h3 class="page-header">Update &raquo; Vitamin</h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-success">
            <div class="panel-heading">
                <strong>Ubah Data</strong>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form role="form" action="" enctype="multipart/form-data" method="post">
                            <div class="form-group has-success">
                                <label>VIT</label>
                                <input class="form-control" type="text" name="namavitamin" value="<?php echo $row_update_vitamin["namavitamin"] ?>" />
                            </div>
                            <div class="form-group has-success">
                                <label>Fungsi</label>
                                <?php echo"<textarea class='form-control' type='text' name='fungsi'>$row_update_vitamin[fungsi]</textarea>"; 
                                ?>
                            </div>
                            <div class="form-group has-success">
                               <label>Kadar</label>
                               <input class="form-control" type="text" name="kadar" value="<?php echo $row_update_vitamin["kadar"] ?>" />
                            </div>
                               <div class="form-group has-success">
                               <label>Sumber Makanan</label>
                               <?php echo"<textarea class='form-control' type='text' name='sumbermakanan'>$row_update_vitamin[sumbermakanan]</textarea>";
                               ?>
                            </div>
                            <button type="submit" name="submit_update_vitamin" class="btn btn-success">Update</button>
                            <button type="submit" name="cancel_update" class="btn btn-warning">Cancel</button>
                            <input type="hidden" name="id_vitamin" value="<?php echo $row_update_vitamin["id"] ?>"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
