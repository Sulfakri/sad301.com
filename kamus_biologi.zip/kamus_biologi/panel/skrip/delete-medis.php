<?php
if (isset($_GET["delete-medis"])) {
	$id = (int)mysql_real_escape_string(trim($_GET["delete-medis"]));
	mysql_query("DELETE FROM istilahpentingmedis WHERE id = '$id';") or die (mysql_error());
}
header("location:index.php?istilah-medis");