<?php

if (empty($_SESSION["administrator_id"])) header("location:login.php");
$sql_istilah = mysql_query("SELECT * FROM istilahbiologi ORDER BY waktu DESC;") or die(mysql_error());
if (isset($_POST["submit_save_istilah"])) {
    $nama = mysql_real_escape_string(trim(ucfirst($_POST["nama"])));
    date_default_timezone_set('Asia/Jakarta');
    $detail = mysql_real_escape_string(trim($_POST["detail"]));
    $cat_huruf = mysql_real_escape_string($_POST["cat-h"]);
    $waktu = date("d-m-y G:i:s");
    $sql_cek_nama = mysql_query("SELECT * FROM istilahbiologi WHERE nama='$nama'") or die(mysql_error());
    if(mysql_num_rows($sql_cek_nama) > 0 ){
      echo "<script>alert('Istilah yang Anda masukkan sudah ada')</script>";
    } else{
      $sql_in = mysql_query("INSERT INTO istilahbiologi VALUES ('','$nama','$detail','$cat_huruf','$waktu');") or die(mysql_error());
    header("location:index.php?crud-istilah");
    }
}
?>

<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Data Istilah Biologi</h3>
    </div>
</div>
<p><a href="#" class="btn btn-success btn-sm" data-toggle="modal" data-target="#tambahData"> <i class="fa fa-plus"></i> Data Baru</a></p>
<br>
<!--Input Data Baru-->
    <div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-hidden="true">
       <div class="modal-dialog">
         <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title"><p class="text-warning"><strong>Tambah Data</strong></p></h4>
                </div>
                    <div class="modal-body">
                        <form role="form" action="" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label>Nama Istilah</label>
                                <input class="form-control" required="required" type="text" name="nama" autofocus/>
                            </div>
                            <div class="form-group">
                                <label>Detail</label>
                                <textarea class="form-control" id="edit1" name="detail" required></textarea>
                            </div>
                            <div class="form-group">
                              <label>Cat Hruf</label>
                              <select name="cat-h" type="text" class="form-control" style="width:80px;" required>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="E">E</option>
                                <option value="F">F</option>
                                <option value="G">G</option>
                                <option value="H">H</option>
                                <option value="I">I</option>
                                <option value="J">J</option>
                                <option value="K">K</option>
                                <option value="L">L</option>
                                <option value="M">M</option>
                                <option value="N">N</option>
                                <option value="O">O</option>
                                <option value="P">P</option>
                                <option value="Q">Q</option>
                                <option value="R">R</option>
                                <option value="S">S</option>
                                <option value="T">T</option>
                                <option value="U">U</option>
                                <option value="V">V</option>
                                <option value="W">W</option>
                                <option value="X">X</option>
                                <option value="Y">Y</option>
                                <option value="Z">Z</option>
                              </select>
                            </div>
                            <button type="submit" name="submit_save_istilah" class="btn btn-primary btn-primary pull-left"><span class="fa fa-plus-square"></span> Simpan</button>
                            &nbsp;
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger btn-danger" data-dismiss="modal"><span class="glyphicon glyphicon-remove"></span>  Tutup</button>
                    </div>
            </div>
       </div>
    </div>

<div class="row">
    <div class="col-md-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <strong>List Data</strong>  
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-bordered table-condensed table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Detail</th>
                        <th>Cat. Hruf</th>
                        <th>Aksi</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($sql_istilah) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_istilah = mysql_fetch_array($sql_istilah)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "odd";
                           } else {
                              $class_background = "even";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?> gradeA">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_istilah["nama"]; ?></td>
                        <td><?php echo $row_istilah["detail"]; ?></td>
                        <td><?php echo $row_istilah["cat_huruf"]; ?></td>
                        <td class="center">
                        <a href="index.php?istilah-update=<?php echo $row_istilah["id"]?>" class="glyphicon glyphicon-edit" type="button" title="Edit"></a> &nbsp;&nbsp; 
                        <a  href="index.php?istilah-delete=<?php echo $row_istilah["id"]; ?>" onclick="javascript: return confirm('Apakah Anda Yakin akan Menghapus Data Ini ?')" class="glyphicon glyphicon-trash" type="button" title="Hapus"></a></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } else { ?>
                    </tbody>
                        <div class="alert alert-danger fade in"> <span class="fa fa-info-circle fa-fw"></span>
                      <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                      Data kosong </div>
                    <?php } ?>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript">
    var editor2 = CKEDITOR.replace('edit1');
</script>

