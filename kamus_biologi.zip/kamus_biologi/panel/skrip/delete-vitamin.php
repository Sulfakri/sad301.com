<?php
if (isset($_GET["delete-vitamin"])) {
	$id = (int)mysql_real_escape_string(trim($_GET["delete-vitamin"]));
	mysql_query("DELETE FROM vitamin WHERE id = '$id';") or die (mysql_error());
}
header("location:index.php?vitamin");