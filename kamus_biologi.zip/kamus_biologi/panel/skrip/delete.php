<?php
if (isset($_GET["istilah-delete"])) {
	$id = (int)mysql_real_escape_string(trim($_GET["istilah-delete"]));
	mysql_query("DELETE FROM istilahbiologi WHERE id = '$id';") or die (mysql_error());
}
header("location:index.php?crud-istilah");