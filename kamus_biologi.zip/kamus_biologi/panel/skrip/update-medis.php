<?php
if (isset($_POST["submit_update_medis"])) {
    $id_medis = mysql_escape_string(trim($_POST["id_medis"]));
    $namaistilah = mysql_escape_string(trim(ucfirst($_POST["namaistilah"])));
    $detail = mysql_escape_string(trim(ucfirst($_POST["detailistilah"])));

$qry_upd = mysql_query("UPDATE istilahpentingmedis SET namaistilah='$namaistilah' , detailistilah='$detail' WHERE id='$id_medis';") or die(mysql_error());
    
    header("location:index.php?istilah-medis");
}
$id = abs((int)$_GET["update-medis"]);
$sql_update_medis = mysql_query("SELECT * FROM istilahpentingmedis WHERE id = '$id';") or die(mysql_error());
$row_update_medis = mysql_fetch_array($sql_update_medis);

if (mysql_num_rows($sql_update_medis)==0) header("location:index.php?istilah-medis");
if (isset($_POST["cancel_update"])) header("location:index.php?istilah-medis");
?>

<div class="row">
    <div class="col-lg-8">
        <h3 class="page-header">Update &raquo; Medis</h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <strong>Ubah Data</strong>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form role="form" action="" enctype="multipart/form-data" method="post">
                            <div class="form-group">
                                <label>Nama Istilah</label>
                                <input class="form-control" type="text" name="namaistilah" value="<?php echo $row_update_medis["namaistilah"] ?>" />
                            </div>
                            <div class="form-group">
                                <label>Detail Istilah</label>
                                <input class="form-control" type="text" name="detailistilah" value="<?php echo $row_update_medis["detailistilah"] ?>" />
                            </div>
                            <button type="submit" name="submit_update_medis" class="btn btn-success">Update</button>
                            <button type="submit" name="cancel_update" class="btn btn-warning">Cancel</button>
                            <input type="hidden" name="id_medis" value="<?php echo $row_update_medis["id"] ?>"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
