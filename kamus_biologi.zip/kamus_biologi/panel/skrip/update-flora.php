<?php
if (isset($_POST["submit_update_flora"])) {
    $id_flora = mysql_escape_string(trim($_POST["id_flora"]));
    $nama = mysql_escape_string(trim(ucfirst($_POST["nama_tumbuhan"])));
    $unsur_obat = mysql_escape_string(trim(ucfirst($_POST["unsur_obat"])));
    $khasiat = mysql_escape_string(trim(ucfirst($_POST["khasiat"])));

$qry_upd = mysql_query("UPDATE floraindo SET nama_tumbuhan='$nama' , unsur_obat='$unsur_obat' , khasiat='$khasiat' WHERE id='$id_flora';") or die(mysql_error());
    
    header("location:index.php?flora-obat");
}
$id = abs((int)$_GET["update-flora"]);
$sql_update_flora = mysql_query("SELECT * FROM floraindo WHERE id = '$id';") or die(mysql_error());
$row_update_flora = mysql_fetch_array($sql_update_flora);

if (mysql_num_rows($sql_update_flora)==0) header("location:index.php?flora-obat");
if (isset($_POST["cancel_update"])) header("location:index.php?flora-obat");
?>

<div class="row">
    <div class="col-lg-8">
        <h3 class="page-header">Update &raquo; Flora</h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-8">
        <div class="panel panel-info">
            <div class="panel-heading">
                <strong>Ubah Data</strong>
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form role="form" action="" enctype="multipart/form-data" method="post">
                            <div class="form-group has-success">
                                <label>Nama Tumbuhan</label>
                                <input class="form-control" type="text" name="nama_tumbuhan" value="<?php echo $row_update_flora["nama_tumbuhan"] ?>" />
                            </div>
                            <div class="form-group has-success">
                                <label>Unsur Obat</label>
                                <input class="form-control" type="text" name="unsur_obat" value="<?php echo $row_update_flora["unsur_obat"] ?>" />
                            </div>
                            <div class="form-group has-success">
                               <label>Khasiat</label>
                               <input class="form-control" type="text" name="khasiat" value="<?php echo $row_update_flora["khasiat"] ?>" />
                            </div>
                            <button type="submit" name="submit_update_flora" class="btn btn-success">Update</button>
                            <button type="submit" name="cancel_update" class="btn btn-warning">Cancel</button>
                            <input type="hidden" name="id_flora" value="<?php echo $row_update_flora["id"] ?>"/>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
