-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24 Sep 2016 pada 20.38
-- Versi Server: 10.1.8-MariaDB
-- PHP Version: 5.6.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kamus_biologi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `administrator`
--

CREATE TABLE `administrator` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `administrator`
--

INSERT INTO `administrator` (`id`, `username`, `password`, `fullname`, `email`) VALUES
(9, 'admin kedua', '5847b7b5a6ecd52cf27c6f62b6e1c327', 'Admin dua', 'sulfakri98@gmail.com'),
(93, 'admin', 'salupa', 'Sulfakri', 'sulfakrisapruddin@gmail.com'),
(710, 'mendez', '83b861efd4ce3bb438dd07435c9e7044', 'Chaton Dimas Syahputra', 'Dimas@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `datetime` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `contact`
--

INSERT INTO `contact` (`id`, `name`, `email`, `message`, `datetime`) VALUES
(1, 'Afmin', 'admin@mail.com', 'komentar', '19-09-2016 13:02:19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `floraindo`
--

CREATE TABLE `floraindo` (
  `id` int(11) NOT NULL,
  `nama_tumbuhan` varchar(255) NOT NULL,
  `unsur_obat` varchar(255) NOT NULL,
  `khasiat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `floraindo`
--

INSERT INTO `floraindo` (`id`, `nama_tumbuhan`, `unsur_obat`, `khasiat`) VALUES
(1, 'Adas', 'Buah', 'Karminatif, aromatik'),
(2, 'Adpokat', 'Daun', 'Diuretik, stomatik'),
(3, 'Alamanda', 'Daun', 'Laksatik'),
(4, 'Asem', 'Buah', 'Korigen'),
(5, 'Bakung kuning', 'Umbi/rimpang', 'Emetik'),
(6, 'Bandotan', 'Akar', 'Tonik'),
(7, 'Bawang merah', 'Daun', 'Febrigua'),
(8, 'Bayam merah', 'Akar/daun', 'Diuretik, emollensia'),
(9, 'Belimbing manis', 'Buah/daun', 'Menurunkan kolestrol'),
(10, 'Bluntas', 'Daun', 'Difotentik'),
(11, 'Bengle', 'Rimpang', 'Karminatif, stimulan'),
(12, 'Besaran/murbei', 'Akar', 'Astrigen'),
(13, 'Bugang kembang', 'Daun/akar', 'Obat batu ginjal'),
(14, 'Cabe/lombok', 'Daun', 'Perut mules, bisul'),
(15, 'Camcau semak / cincau', 'Daun/akar', 'Febrifuga'),
(16, 'Ceguk/wudani', 'Daun/biji', 'Antelmintik'),
(17, 'Cempaka kuning', 'Kulit/kayu', 'Tonik, astrigen, febrifugua'),
(18, 'Cempaka kuning', 'Daun/akar', 'Vermifuga, purgatif'),
(19, 'Cempaka putih', 'Daun/bunga', 'Astrigien, aromatik'),
(20, 'Cengkeh', 'Daun/bunga', 'Obat sakit gigi'),
(21, 'Cepaka piring/kaca piring', 'Daun', 'Hipotensi, ekspektoran'),
(22, 'Ceplukan', 'Daun', 'Anti diabetik'),
(23, 'Ceraka merah', 'Akar', 'Sudarifik (obat luar)'),
(24, 'Ceraka merah', 'Daun', 'Reumatik (obat luar)'),
(25, 'Cermi/cerme', 'Daun', 'Anti abesitas'),
(26, 'Cerme belanda', 'Daun', 'Pelangsing'),
(27, 'Dadap', 'Akar', 'Emetik'),
(28, 'Dadap ayam', 'Daun', 'Febrifuga'),
(29, 'Delima merah', 'Buah', 'Obat diare'),
(30, 'Delima putih', 'Buah', 'Flour albus'),
(31, 'Delingo/deringo', 'Buah', 'Tonik syaraf, demam panas'),
(32, 'Dondong laut', 'Rimpang', 'Aromatik, astrigen, anti BB'),
(33, 'Duduk daun', 'Daun/akar', 'Obat ambeien/wasir, tonik'),
(34, 'Duku', 'Daun', 'Astrigen, disentri'),
(35, 'Ekaliptus', 'Biji', 'Antiseptik, obat rematik, obat asma'),
(36, 'Ekaliptus', 'Biji', 'Obat asma'),
(37, 'Encok daun', 'Daun/akar', 'Obat rematik, obat kurap'),
(38, 'Gagan/pegagan', 'Herba', 'Obat kulit, sedatif'),
(39, 'Jagung', 'Rambut buah', 'Diuretik'),
(40, 'Gagan/pegagan', 'Herba', 'Obat kulit, sedatif'),
(41, 'Jahe', 'Tongkil muda', 'Laktagoga'),
(42, 'Jali batu', 'Buah/biji', 'Tonik, radang usus'),
(43, 'Jambu biji', 'Daun', 'Obat diare'),
(44, 'Jambu monyet', 'Daun', 'Obat kulit (obat luar)'),
(45, 'Jarak kaliki', 'Biji/daun', 'Obat kulit, laksatif'),
(46, 'Jarak pager', 'Getah', 'Obat sariawan'),
(47, 'Jengkol/jarring', 'Daun', 'Obat kulit'),
(48, 'Jeruk bali', 'Kulit/buah', 'Penghalus kulit'),
(49, 'Jeruk kingkit', 'Daun', 'Aromatik, obat diare'),
(50, 'Jeruk nipis', 'Buah', 'Stimulan, obat batuk'),
(51, 'Jeruk pepaya', 'Bunga', 'Astringen'),
(52, 'Jeruk purut', 'Buah', 'Obat batuk, aromatic'),
(53, 'Jinten daun', 'Daun', 'Sariawan, obat batuk'),
(54, 'Jinten hitam', 'Biji', 'Stimulan, karminatif'),
(55, 'Kamboja', 'Kulit/daun', 'Purgatif, febrifuga'),
(56, 'Kapas gading', 'Akar/biji', 'Abortivum'),
(57, 'Kapok randu', 'Daun/kulit', 'Emmoliensia, obat batuk'),
(58, 'Kayu merah', 'Daun/kulit', 'Obat kulit'),
(59, 'Kayu putih/gelam', 'Daun/buah', 'Stomachik, karminatif'),
(60, 'Kecubung gunung', 'Daun', 'Obat asma'),
(61, 'Kecubung putih', 'Daun', 'Obat asma, obat encok'),
(62, 'Kecubung wulung', 'Biji', 'Obat asma, obat encok'),
(63, 'Kedawung', 'Biji', 'Karminatif, obat diare'),
(64, 'Kedele', 'Biji/kulit', 'Sumber protein, astringen'),
(65, 'Kedondong', 'Daun/ranting', 'Obat disentrim, obat diare'),
(66, 'Kedondong', 'Buah', 'Sumber vitamin c'),
(67, 'Kelapa gading', 'Air buah', 'Anti piretik'),
(68, 'Kelapa gading', 'Akar', 'Obat disentri'),
(69, 'Kelor', 'Daun', 'Emetik'),
(70, 'Kelor', 'Akar', 'Tonik syaraf'),
(71, 'Kemandilan', 'Daun', 'Salah urat'),
(72, 'Kemangi', 'Daun', 'Aromatik'),
(73, 'Kemangi', 'Biji', 'Stimulan'),
(74, 'Kembang sepatu', 'Daun', 'Febrifuga'),
(75, 'Kembang sepatu', 'Akar', 'Obat batuk'),
(76, 'Kembang sepatu', 'Bunga', 'Zat warna'),
(77, 'Kemuning', 'Daun', 'Antidota, antabesitas'),
(78, 'Kenanga', 'Bunga', 'Aromatik'),
(79, 'Kencur', 'Rimpang', 'Roboransia'),
(80, 'Kenikir', 'Daun', 'Alteritif'),
(81, 'Kentut daun', 'Daun', 'Obat nyeri usus, lambung'),
(82, 'Kentut daun', 'Daun', 'Obat nyeri usus, lambung'),
(83, 'Kerendang', 'Daun', 'Obat kulit'),
(84, 'Ketela rambat', 'Umbi/akar', 'Tonik, laksatif'),
(85, 'Ketela rambat', 'Daun', 'Anti diabetik'),
(86, 'Ketela pohon', 'Daun', 'Obat beri-beri'),
(87, 'Ketimun/mentimun', 'Buah/air buah', 'Penghalus kulit'),
(88, 'Ketumbar', 'Buah', 'Karminatif'),
(89, 'Kina ledgeriana', 'Kulit kayu', 'Obat malaria, antiperetik'),
(90, 'Kolasom', 'Akar', 'Aprodisiak, tonik'),
(91, 'Krambilan', 'Daun/akar', 'Diuretik'),
(92, 'Kucai', 'Umbi lapis', 'Anti kejang, aromatik'),
(93, 'Kumis kucing', 'Daun', 'Diuretik, obat batu ginjal'),
(94, 'Kunci masak', 'Rimpang', 'Diare'),
(95, 'Kunyit', 'Rimpang', 'Kholagoga, disinfektan'),
(96, 'Kuping macan', 'Akar', 'Diuretik'),
(97, 'Kuping macan', 'Akar', 'Diuretik'),
(98, 'Kuping macan', 'Daun', 'Febrifuga'),
(99, 'Labu parang', 'Buah/biji', 'Laksatif, antelmitik'),
(100, 'Labu siam', 'Buah', 'Obat sariawan, ambeien'),
(101, 'Lempuyang', 'Rimpang', 'Stomachik'),
(102, 'Lempuyang gajah', 'Rimpang', 'Stomachik'),
(103, 'Lempuyang wangi', 'Rimpang', 'Stimulan'),
(104, 'Lidah buaya', 'Daun/lender', 'Penumbuh rambut, obat batuk'),
(105, 'Lobak', 'Daun/akar', 'Laksatif'),
(106, 'Lobak', 'Bunga', 'Stimulan'),
(107, 'Mangga/pelem', 'Biji', 'Obat diare'),
(108, 'Merica/lada hitam', 'Buah/biji', 'Karminatif'),
(109, 'Melati', 'Akar', 'Obat cuci mata'),
(110, 'Melati', 'Bunga/daun', 'Laktifuga'),
(111, 'Nangka', 'Daun/pucuk', 'Laktagoga'),
(112, 'Nangka', 'Daun/akar', 'Laksatif'),
(113, 'Sirsak', 'Buah/biji', 'Sariawan, abortivum'),
(114, 'Sirsak', 'Daun', 'Insektisida, emetik'),
(115, 'Nenas/nanas', 'Buah muda', 'Antilmintik'),
(116, 'Nenas/nanas', 'Buah masak', 'Radang amandel, obat mulas'),
(117, 'Orang aring', 'Herba', 'Hair tonik (menghitamkan rambut)'),
(118, 'Pacar air', 'Daun', 'Obat bisul'),
(119, 'Pacar air', 'Daun', 'Obat bisul'),
(120, 'Pacar air', 'Bunga/biji', 'Obat encok'),
(121, 'Pacar cina', 'Daun', 'Mengurangi pendarahan pada waktu haid'),
(122, 'Pacar kuku', 'Daun', 'Astringen'),
(123, 'Pacar kuku', 'Bunga', 'Fluir albus'),
(124, 'Pace/mengkudu', 'Buah', 'Anti hipertensi'),
(125, 'Pandan wangi', 'Daun', 'Aromatik'),
(126, 'Pandan wangi', 'Akar', 'Diuretik'),
(127, 'Pala', 'Buah/kulit/biji', 'Karminatif'),
(128, 'Patah tulang', 'Daun/ranting', 'Rematik'),
(129, 'Pecut kuda', 'Daun/akar', 'Dismonorchoe'),
(130, 'Papaya/pare', 'Daun', 'Laksatif'),
(131, 'Papaya/pare', 'Buah/biji', 'Obat disentri'),
(132, 'Pinang', 'Biji', 'Obat Diare'),
(133, 'Pisang batu', 'Buah', 'Astringen'),
(134, 'Pukul empat', 'Bunga/akar', 'Furgatif'),
(135, 'Pukul empat', 'Daun', 'Diuretik'),
(136, 'Putri malu', 'Herba', 'Tonik, diuretik'),
(137, 'Rumput betung', 'Herba', 'Diuretic'),
(138, 'Saga', 'Daun', 'Sariawan, emetik'),
(139, 'Salam', 'Daun', 'Obat diare'),
(140, 'Sambiloto', 'Herba', 'Febrifuga'),
(141, 'Sari manis/stevia', 'Daun', 'Sari manis/pemanis'),
(142, 'Sawo', 'Biji', 'Antelmintik'),
(143, 'Sawo', 'Akar', 'Astringen'),
(144, 'Selasih', 'Daun', 'Aromatic, obat batuk'),
(145, 'Sembung', 'Daun/bongkol', 'Karminatif, ekspektoran'),
(146, 'Sereh masak', 'Daun/bongkol', 'Aromatik'),
(147, 'Sereh minyak', 'Herba', 'Rematik'),
(148, 'Seribu daun', 'Daun', 'Emenagoga'),
(149, 'Sirih', 'Daun', 'Obat batuk, antiseptik'),
(150, 'Sirih gading', 'Daun', 'Obat pencuci mata'),
(151, 'Sosor bebek', 'Bunga', 'Disentri, diare'),
(152, 'Tanjung', 'Bunga', 'Astringen, obat asma'),
(153, 'Tanjung', 'Buah/biji', 'Obat diare'),
(154, 'Tapak liman', 'Akar', 'Febrifuga'),
(155, 'Tapak liman', 'Batang', 'Astringen'),
(156, 'Tapak liman', 'Daun', 'Tambah darah'),
(157, 'Tebu ireng', 'Akar', 'Laksatif'),
(158, 'Teki/rumput teki', 'Akar', 'Analgetik'),
(159, 'Telesom', 'Akar', 'Aprodisiak'),
(160, 'Tembakau', 'Daun', 'Sedatik, narkotik, emetik'),
(161, 'Tempuyung', 'Daun', 'Litotriptik'),
(162, 'Temu giring', 'Rimbang', 'Antiabesitas'),
(163, 'Temu lawak', 'Rimbang', 'Amarum, laksatif'),
(164, 'Temu putih', 'Rimbang', 'Stomachik'),
(165, 'Teratai', 'Daun/bunga', 'Disentri'),
(166, 'Terong leunca', 'Daun', 'Anti diabetik'),
(167, 'Terong pokak', 'Buah', 'Laksatif'),
(168, 'Terong pokak', 'Daun', 'Sedatif'),
(169, 'Tomat', 'Buah', 'Tonik, sumber vitamin a dan c'),
(170, 'Turi', 'Kulit kayu', 'Diare, radang usus'),
(171, 'Urat daun', 'Herba', 'Laktagoga'),
(172, 'Valerian', 'Daun', 'Anti spasmodik'),
(173, 'Viola hutan', 'Daun', 'Emolliensia'),
(174, 'Viola hutan', 'Bunga', 'Ekspektoran'),
(175, 'Viola hutan', 'Akar', 'Emetik'),
(176, 'Wali songo', 'Daun', 'Refrigeran'),
(177, 'Waru', 'Daun', 'Laksatif'),
(178, 'Waru', 'Akar', 'Febrifuga'),
(179, 'Tes', 'Tes', 'Tes tes saja'),
(181, 'Kemangi', 'Daun', 'Untuk mengurangi bau tak sedap pada tubuh; sebagai campuran bumbu makanan'),
(182, 'Adas', 'Adasss', 'Asaaaa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `istilahbiologi`
--

CREATE TABLE `istilahbiologi` (
  `id` int(11) NOT NULL,
  `nama` text NOT NULL,
  `detail` text NOT NULL,
  `cat_huruf` text NOT NULL,
  `waktu` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `istilahbiologi`
--

INSERT INTO `istilahbiologi` (`id`, `nama`, `detail`, `cat_huruf`, `waktu`) VALUES
(1, 'A (A)', '<p>lambang yang dipergunakan untuk menandakan perangkat haploid autosom</p>', 'A', '24-09-16 22:20:46'),
(2, 'AI, AH (Al, All)', '<p>anafase yang terjadi terutama pada pembelahan meiosis, pada tingkat pertama dan kedua</p>', 'A', '24-09-16 22:20:54'),
(3, 'A posteriori', '<p>metode penalaran, yang akan dimulai dengan teori atau penyebab, untuk kemudian memastikan fakta atau pengaruh</p>', 'A', '25-09-16 00:13:56'),
(4, 'A priori', '<p>metode penalaran, untuk memastikan teori atau penyebab, untuk kemudian memastikan fakta atau pengaruh</p>', 'A', '25-09-16 00:14:04'),
(5, 'ABA', '<p><em>(ABA)&nbsp;</em>lihat : asam abisat</p>', 'A', '25-09-16 00:14:11'),
(6, 'Abaksial', '<p>bagian yang berada permukaan atau sisi suatu organ yang jauh atau menjauhi sumbu panjang tempat melekatnya; lihat adaksial</p>', 'A', '25-09-16 00:14:19'),
(8, 'Abduksi', '<p>aktivasi anggota tubuh menjauhi poros median atau menjauhi badan</p>', 'A', '25-09-16 00:15:20'),
(9, 'Aberasi', '<p>kromosom yang mengalami ketidaknormalan yang merupakan akibat terjadinya penghilangan, duplikasi, inversi, translokasi, ataupun pengaturan kembali meteri genetika</p>', 'A', '25-09-16 00:15:35'),
(10, 'Aberasi kromosom', '<p>perubahan yang terjadi pada susunan struktur dan jumlah suatu kromosom di dalam sel merupakan suatu akibat kehilangan, duplikasi atau pengaturan kembali bahan genetika, yang dapat menimbulkan perubahan ciri yang turun-temurun pada organisme yang mengalaminya</p>', 'A', '25-09-16 00:15:42'),
(11, 'Abiens', '<p>reaksi penghindaran</p>', 'A', '25-09-16 00:15:57'),
(12, 'Abiogenesis', '<p>konsep generasi spontan yang menyatakan bahwa kehidupan dapat muncul dari benda tak hidup</p>', 'A', '25-09-16 00:16:05'),
(14, 'Abioseston', '<p>komponen mati pada keseluruhan zarah yang yang tersuspensi dalam air; tripton</p>', 'A', '25-09-16 00:16:14'),
(15, 'Abioseon', '<p>suatu komponen nir-biotik suatu ekosistem atau habitat</p>', 'A', '25-09-16 00:16:27'),
(16, 'Abiotik', '<p><strong>1&nbsp;</strong>tak hidup, tidak memiliki ciri hidup;&nbsp;<strong>2&nbsp;</strong>berkenaan atau dicirikan oleh tidak adanya organisme hidup;&nbsp;<strong>3&nbsp;</strong>benda tak hidup, seperti batu-batuan, tembok, dan bangunan rumah yang merupakan unsur abiotik ekosistem</p>', 'A', '25-09-16 00:16:36'),
(17, 'Abiotrofi', '<p>gejala yang menunjukkan bahwa berbagai sel atau jaringan mencapai umur maksimum yang berbeda-beda</p>', 'A', '25-09-16 00:16:46'),
(18, 'Abisal', '<p>zona dikedalaman laut yang tidak dapat ditembus cahaya; biasanya dalam oseanografi adalah kedalaman di bawah 2000 m, tetapi hanya untuk kedalaman, antara 4000 dan 6000 m</p>', 'A', '25-09-16 00:16:59'),
(19, 'Abisobentos', '<p>organisme yang berhabitat pada dataran atau zona abisal</p>', 'A', '25-09-16 00:17:07'),
(20, 'Abisopelagik', '<p>zona atau organisme yang hidup pada kolom air samudra pada kedalaman 4000-6000 m di atas dasar samudra</p>', 'A', '25-09-16 00:17:15'),
(21, 'Abjeksi', '<p>pemisahan suatu spora dari pembawanya (misalnya sterigma, konidifior) berdasarkan kekuatan dari dalam jamur sendiri</p>', 'A', '25-09-16 00:17:25'),
(22, 'Ablasi', '<p>penghilangan dengan pembedahan jaringan atau organ tubuh</p>', 'A', '25-09-16 00:17:34'),
(23, 'Ablastin', '<p>antibodi yang secara spesifik menghambat perkembangbiakan jasad renik, yaitu secara bergabung dengan antigen dari permukaan sel homolog</p>', 'A', '25-09-16 00:17:41'),
(24, 'Abnormal', '<p>sifat atau keadaan yang menyimpang dari yang normal</p>', 'A', '25-09-16 00:17:50'),
(25, 'Aboospora', '<p>spora yang dihasilkan dari gamet betina tak terbuahi; azigospora, partenospora</p>', 'A', '25-09-16 00:18:01'),
(26, 'Aboral', '<p>terletak jauh dari mulut, atau ke arah yang menjauhi mulut</p>', 'A', '25-09-16 00:18:09'),
(27, 'Aborsi', '<p><strong>1&nbsp;</strong>pengguguran kandungan;&nbsp;<strong>2&nbsp;</strong>penghentian pertumbuhan organ</p>', 'A', '25-09-16 00:18:17'),
(28, 'Aborsi nekrogen', '<p>kematian cepat jaringan tumbuhan sekitar titik serangan patogen sehingga menghambat penyebaran patogen lebih lanjut</p>', 'A', '25-09-16 00:18:26'),
(29, 'Abrasi', '<p>proses erosi dengan cara menggosok, mengikis atau menghauskan, permukaan bahan</p>', 'A', '25-09-16 00:18:35'),
(30, 'Abrasif', '<p>zarah halus bahan seperti arang atau karborundum yang dicampurkan pada inokulum atau ditaburkan pada permukaan daun untuk memudahkan transmisi mekanis virus tanaman</p>', 'A', '25-09-16 00:18:45'),
(31, 'Abses', '<p>kumpulan nanah setempat di dalam rongga yang terbentuk akibat hancurnya jaringan</p>', 'A', '25-09-16 00:18:53'),
(32, 'Absis', '<p>sumbu horizontal atau sumbu x suatu grafik; bandingkan ordinat</p>', 'A', '25-09-16 00:19:02'),
(33, 'Absisi', '<p>peluruhan secara terkendali suatu bagian (seperti daun bunga atau buah) oleh tumbuhan, yang prosesnya berkaitan dengan perubahan tingkat kandungan auksin dalam bagian yang akan gugur, atau dengan menghilangkan lapisan atau dinding penghubung</p>', 'A', '25-09-16 00:19:12'),
(34, 'Absisin', '<p>(<em>abscisic acid</em>) lihat: asam abisat</p>', 'A', '25-09-16 00:19:22'),
(35, 'Absorpsi', '<p><strong>1&nbsp;</strong>proses pengambil suatu substansi (absorbat) ke dalam dan menjadi bagian substansi (absorben) lain;&nbsp;<strong>2&nbsp;</strong>dalam energetika ekosistem, bagi konsumsi yang tidak dikeluarkan sebagai egesta;&nbsp;<strong>3&nbsp;</strong>penyerapan bahan nutritif atau cairan oleh sel atau jaringan hidup</p>', 'A', '25-09-16 00:19:32'),
(36, 'Acak', '<p>kemungkinan atau peluang yang tidak ditentukan terlebih dulu, tetapi terbuka dan sama serta tanpa pola</p>', 'A', '25-09-16 00:19:40'),
(37, 'Acalculia', '<p>keadaan hilangnya daya hitung</p>', 'A', '25-09-16 00:19:50'),
(38, 'Acapnia', '<p>penurunan kadar karbon dioksida dalam arah</p>', 'A', '25-09-16 00:19:59'),
(39, 'AcCoA', '<p>(<em>acetyl coenzym A</em>) bentuk koenzim a yang telah mengalami asetilasi, merupakan pemeran langsung, siklus asam sitrat, oksidasi dan sintesis asam lemak, serta dalam berbagai reaksi metabolisme lainnya</p>', 'A', '25-09-16 00:20:08'),
(40, 'ACTH', '<p>(<em>adrenocorticotropic hormone</em>) polipeptida yang dihasilkan cuping depan kelenjar pituitari yang mengatur pertumbuhan dari kegiatan sekretori korteks adrenal</p>', 'A', '25-09-16 00:20:22'),
(42, 'Acuan bibliografi', '<p>dalam tata nama pencantuman nama pengarang dan tahun terbit karyanya, sering diikuti judul berkala atau buku serta nomor jilid dan halaman&nbsp;</p>', 'A', '25-09-16 00:20:45'),
(43, 'Acuitas', '<p>ketajaman, terutama mengenai penglihatan</p>', 'A', ''),
(44, 'Acute abdomen', '<p>nyeri perut yang disebabkan oleh radang, perforasi, infark atau ruptur usus</p>', 'A', ''),
(45, 'Acutus, akut', '<p>mendadak tajam, pedih peristiwa yang singkat dan berat</p>', 'A', ''),
(46, 'Ada', '<p>dalam ilmu biologi berarti terdapat masih hidup pada saat sekarang ini; bandingkan punah</p>', 'A', ''),
(47, 'Adamantine', '<p>email gigi</p>', 'A', ''),
(48, 'Adamantinoma', '<p>neoplasma berasal dari epitel email gigi sering kali mengelilingi retikulum stelat, terdapat terutama mandibula</p>', 'A', ''),
(49, 'Adaksial', '<p>bagian, permukaan atau sisi suatu organ yang dekat dengan, mendekati, ataupun menghadap sumbu panjang tempat melekatnya; lihat juga abaksial</p>', 'A', ''),
(50, 'Adaptasi', '<p><strong>1&nbsp;</strong>usaha penyesuaian makhluk di dalam lingkungan tempat hidupnya untuk memperbaiki kesempatan sintasan atau kelangsungan hidupnya dan akhirnya meneruskan sifat penyesuaiannya kepada keturunannya;&nbsp;<strong>&nbsp;2&nbsp;</strong>perubahan pada suatu makhluk sebagai reaksi terhadap keadaan baru ini;&nbsp;<strong>&nbsp;3&nbsp;</strong>perubahan tanggapan terhadap rangsangan suatu alat perasa sebagai hasil rangsangan yang terus menerus&nbsp;sehingga rangsangan yang lebih berat atau intensif diperlukan untuk menghasilkan tanggapan yang sama;&nbsp;<strong>4&nbsp;</strong>penyesuaian terhadap gangguan pada sistem saraf tanpa melibatkan pusat koordinasi</p>', 'A', ''),
(51, 'Adaptasi gelap', '<p>penyesuaian pupil mata pada gelap atau cahaya remang yang menurun intensitasnya</p>', 'A', ''),
(52, 'Aerobik', '<p>Bakteri (dan sel lain) yang melakukan pernafasan dengan menggunakan oksigen bebas.</p>', 'A', ''),
(53, 'Agen', '<p>bibit penyakit</p>', 'A', ''),
(55, 'Alogami', '<p>Penyerbukan yang terjadi jika serbuk sari berasal dari bunga pohon lain yang sejenis</p>', 'A', ''),
(56, 'Altituda', '<p>Letak suatu daerah bardasarkan tingginya dari permukaan air laut.</p>', 'A', ''),
(57, 'AMDAL', '<p>(Analisis Mengenai Dampak Lingkungan) kajian mengenai dampak besar dan penting suatu usaha dan/atau kegiatan yang direncanakan pada lingkungan hidup yang diperlukan bagi proses pengambilan keputusan tentang penyelenggaraan usaha dan/atau kegiatan di Indonesia.</p>', 'A', ''),
(58, 'Anaerobik', '<p>Bakteri (dan sel lain) yang melakukan pernafasan tanpa memerlukan oksigen bebas.</p>', 'A', ''),
(59, 'Anemogami', '<p>Penyerbukan yang diperantarai oleh angin.</p>', 'A', ''),
(60, 'Akinet', '<p>sel berdinding tebal pada Cyanobacteria.</p>', 'A', ''),
(61, 'Ametabola', '<p>perkembangan insekta berupa pertambahan ukuran saja tanpa perubahan bentuk.</p>', 'A', ''),
(62, 'Amebosit', '<p>&nbsp;sel-sel seperti Amoeba pada bagian mesoglea porifera yang befungsi mengedarkan makanan dan oksigen ke sel-sel tubuh lainnya.</p>', 'A', ''),
(63, 'Angiospermae', '<p>Tumbuhan biji terbuka.</p>', 'A', ''),
(64, 'Anteridiofor', '<p>Tangkai anteridium.</p>', 'A', ''),
(65, 'Anteridium', '<p>Organ pembentuk sel kelamin jantan (spermatozoid) pada tumbuhan paku atau lumut.</p>', 'A', ''),
(66, 'Antibodi', '<p>Zat yang dibentuk dalam darah untuk memusnahkan bakteri/kuman.</p>', 'A', ''),
(67, 'Antigen', '<p>Zat yang dapat merangsang pembentukan antibodi jika diinjeksikan ke dalam tubuh</p>', 'A', ''),
(68, 'Antitoksin', '<p>Zat pelawan antigen (benda asing yang masuk tubuh)</p>', 'A', ''),
(69, 'Antropogami', '<p>Penyerbukan yang dibantu oleh manusia; disebut juga penyerbukan sengaja atau buatan.</p>', 'A', ''),
(70, 'Aplanospora', '<p>&nbsp;Spora yang tidak memiliki flagela</p>', 'A', ''),
(71, 'Arkegonium', '<p>Bagian tubuh tumbuhan yang berfungsi untuk alat reproduksi; menghasilkan sel gamet betina (Ovum)</p>', 'A', ''),
(72, 'Autogami', '<p>Penyerbukan sendiri</p>', 'A', ''),
(73, 'Autotrof', '<p>Organisme berklorofil yang mampu mengubah zat anorganik menjadi zat organik.</p>', 'A', ''),
(74, 'Avitaminosis', '<p>Penyakit yang disebabkan kekurangan vitamin.</p>', 'A', ''),
(75, 'Badan kutub (polar body)', '<p>Produk meiosis seluler haploid yang tidak fungsional, selain oosit</p>', 'B', '25-09-16 00:23:46'),
(76, 'Bakteri (bacterium)', '<p>Mikroorganisme bersel tunggal yang tidak memiliki inti sel sejati.</p>', 'B', '25-09-16 00:24:01'),
(77, 'Basidiokarp', '<p>Tubuh buah yang merupakan tempat tumbuhnya basidium dalam Basidiomycota</p>', 'B', '25-09-16 00:24:18'),
(78, 'Basidiomycota', '<p>Jamur makroskopik.</p>', 'B', '25-09-16 00:24:36'),
(79, 'Basil (bacillus)', '<p>Bakteri berbentuk batang</p>', 'B', '25-09-16 00:24:52'),
(80, 'Batial', '<p>Pembagian bioma air laut dengan kedalaman daerah 200 &ndash; 2000 meter</p>', 'B', '25-09-16 00:25:07'),
(81, 'Beri â€“ beri', '<p>penyakit yang disebabkan kekurangan vitamin B</p>', 'B', '25-09-16 00:25:28'),
(82, 'Bibit Unggul', '<p>Bibit hasil seleksi secara buatan yang mempunyai sifat &ndash; sifat sesuai dengan keinginan kita.</p>', 'B', '25-09-16 00:25:41'),
(83, 'Binomial nomenklatur', '<p>Penamaan jenis (spesies) dengan menggunakan dua nama</p>', 'B', '25-09-16 00:25:56'),
(84, 'Biodiversitas', '<p>Keanekaragaman hayati.</p>', 'B', '25-09-16 00:26:11'),
(85, 'Biogenesis', '<p>Teori yang menyatakan bahwa makhluk hidup berasal dari makhluk hidup</p>', 'B', '25-09-16 00:26:50'),
(86, 'Bioma', '<p>Sekelompok makhluk hidup yang menempati daerah luas di permukaan bumi.</p>', 'B', '25-09-16 00:27:09'),
(87, 'Biosfer', '<p>Lapisan bumi yang dihuni oleh makhluk hidup</p>', 'B', ''),
(88, 'Bioteknologi', '<p>Teknologi yang menggunakan makhluk hidup untuk menghasilkan produk yang berharga bagi manusia</p>', 'B', ''),
(89, 'Biotik', '<p>Makhluk hidup, benda hidup.</p>', 'B', ''),
(90, 'Blastokist', '<p>(<em>blastocyst</em>)&nbsp;Embrio mamalia saat memasuki dinding uterus</p>', 'B', ''),
(91, 'Blastomer', '<p>(<em>blastomere</em>)&nbsp;Salah satu sel hasil pembuahan sel telur di tahap awal</p>', 'B', ''),
(92, 'Blastula', '<p>Bola sel berongga yang dihasilkan dari pembelahan sel tahap awal pada perkembangan embrio.</p>', 'B', ''),
(93, 'BOD', '<p>(<em>Biological Oxygen Demand</em>)&nbsp;Kebutuhan oksigen secara biologis</p>', 'B', ''),
(94, 'Brakte', '<p>(<em>bractea</em>)&nbsp;Salah satu bagian bunga, yaitu daun pelindung yang berfungsisebagai penarik perhatian serangga penyerbuk</p>', 'B', ''),
(95, 'Bryophyta', '<p>Divisi lumut daun</p>', 'B', ''),
(96, 'Cagar alam', '<p>Upaya pelestarian semua sumber daya alam yang ada untuk tidak dimanfaatkan agar terjaga kelestariannya</p>', 'C', ''),
(97, 'Carolus Linnaeus', '<p>Tokoh yang mencetuskan system penamaan spesies dan penamaan berbagai macam tumbuhan.</p>', 'C', ''),
(98, 'Charles Darwin', '<p>Pelopor sistem klasifikasi berdasarkan filogeni</p>', 'C', ''),
(99, 'Chlamydomonas', '<p>Contoh dari chlorophyta bersel tunggal yang dapat bergerak</p>', 'C', ''),
(100, 'Chlorella', '<p>Contoh dari chlorophyta bersel tunggal tidak dapat bergerak</p>', 'C', ''),
(101, 'Chlorophyta', '<p>Alga Hijau</p>', 'C', ''),
(102, 'Chrysophyceae', '<p>&nbsp;Alga Cokelat-Keemasan</p>', 'C', ''),
(103, 'Chrysophyta', '<p>Alga Keemasan</p>', 'C', ''),
(104, 'Ciliata', '<p>Protista bersel satu yang permukaan tubuhnya memiliki banyak rambut getar (silia)</p>', 'C', ''),
(105, 'Ciri poligenik', '<p>(<em>polygenic trait</em>)&nbsp;Ciri fenotipe yang dipengaruhi beberapa gen.</p>', 'C', ''),
(106, 'Coniferophyta', '<p>Tumbuhan pembawa kerucut, karena alat reproduksinya berbentuk kerucut (strobilus).</p>', 'C', ''),
(107, 'Culex', '<p>Sejenis nyamuk rumah yang menyebarkan larva cacing Filaria penyebab penyakit kaki gajah</p>', 'C', ''),
(108, 'Cyanobacteria', '<p>&nbsp;Alga Hijau-Biru</p>', 'C', ''),
(109, 'Cyanophyta', '<p>&nbsp;Alga Biru</p>', 'C', ''),
(110, 'Cycas rumphii', '<p>Pakis haji</p>', 'C', ''),
(111, 'Adiantum cunaetum', '<p>suplir, digunakan untuk tanaman hias</p>', 'A', ''),
(112, 'Acustica', '<p>rangsangan yang hanya merancang suatu &nbsp;pancaindra tertentu, contohnya : mata hanya menerima cahaya</p>', 'A', ''),
(113, 'Acromegalia', '<p>membesarnya secara abnormal tulang-tulang kepala, kaki, tangan, muka karena adanya perubahan-perubahan dalam endrokin</p>', 'A', ''),
(114, 'Amboceptor', '<p>bagian plasma darah yang berfungsi sebagai penghubung antara berjenis zat dalam serum</p>', 'A', ''),
(115, 'Arrhenotoki', '<p>terjadinya binatang-binatang jantan dari telur-telur yang tidak dibuahi</p>', 'A', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `istilahpentingmedis`
--

CREATE TABLE `istilahpentingmedis` (
  `id` int(11) NOT NULL,
  `namaistilah` varchar(255) NOT NULL,
  `detailistilah` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `istilahpentingmedis`
--

INSERT INTO `istilahpentingmedis` (`id`, `namaistilah`, `detailistilah`) VALUES
(1, 'Antiseptik', 'Mematikan kuman'),
(2, 'Analgetik', 'Menghilangkan rasa nyeri'),
(3, 'Aboetivum', 'Mengakibatkan keguguran'),
(4, 'Antelmintik', 'Menyeluruh/mengeluarkan cacing'),
(5, 'Antidota', 'Melawan/penawar bisa'),
(6, 'Antiperiodik', 'Mencegah penyakit yang selalu kambuh'),
(7, 'Antispasmodik', 'Meredakan kejang'),
(8, 'Afrodisiak', 'Menguatkan lemah syahwat'),
(9, 'Anhidrotik', 'Mengurangi keluarnya keringat'),
(10, 'Karminatif', 'Peluruh air kencing'),
(11, 'Diaforetik/Sudorifik', 'Meluruh/memperbanyak keringat'),
(12, 'Deuretik', 'Peluruh air kencing'),
(13, 'Ametik', 'Menimbulkan muntah'),
(14, 'Emmenagoga', 'Membersihkan haid'),
(15, 'Emolliensia', 'Obat penghalus kulit'),
(16, 'Antipiretik/Febrifuga', 'Menurunkan demam'),
(17, 'Insektisida', 'Membunuh serangga'),
(18, 'Laktifuga', 'Menghentikan/mengurangi keluarnya air susu'),
(19, 'Laktogoga', 'Menderaskan keluarnya air susu'),
(20, 'Narkotik', 'Membius'),
(21, 'Purgatif', 'Urus-urus (cuci perut)'),
(22, 'Refrigeren', 'Menghilangkan dahaga/mendinginkan'),
(23, 'Sedatif', 'Penenang'),
(24, 'Stimulan', 'Membangkitkan / perangsang'),
(25, 'Stomachik', 'Menguatkan lambung / mem-bangkitkan selera'),
(26, 'Tonik', 'Menguatkan'),
(27, 'Ekspektoran', 'Memudahkan batuk / mengeluarkan darah'),
(28, 'Hair Tonik', 'Memperkuat / menumbuhkan rambut'),
(29, 'Diabetik', 'Kencing manis'),
(30, 'Laksatif', 'Pencahar/urus-urus'),
(31, 'Amarum', 'Memacu nafsu makan/zat bersifat pahit yang membangkitkan selera'),
(32, 'Alteratif', 'Memacu enzim-enzim pencernaan'),
(33, 'Khalagoga', 'Peluruh empedu'),
(34, 'Dessinfektan', 'Mematikan hama'),
(35, 'Astrigen', 'Memperkecil pori-pori / menciutkan selaput lendir'),
(36, 'Flour Albus', 'Keputihan'),
(37, 'Limotitis', 'Banyak lemak / penimbunan lemak'),
(38, 'Litotriptik', 'Menghancurkan batu pada kemih'),
(39, 'Korigen', 'Merubah bau/rasa yang tidak enak'),
(40, 'Aromatik', 'Mengharumkan'),
(41, 'Dismenohoe', 'Haid terasa nyeri'),
(42, 'Haemostatik', 'Mengurangi pendarahan'),
(43, 'Roboransia', 'Menyegarkan'),
(44, 'Vermifuga', 'Peluruh cacing'),
(45, 'Hipertensi', 'Tekanan darah tinggi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `vitamin`
--

CREATE TABLE `vitamin` (
  `id` int(11) NOT NULL,
  `namavitamin` varchar(255) NOT NULL,
  `fungsi` varchar(255) NOT NULL,
  `kadar` varchar(255) NOT NULL,
  `sumbermakanan` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `vitamin`
--

INSERT INTO `vitamin` (`id`, `namavitamin`, `fungsi`, `kadar`, `sumbermakanan`) VALUES
(1, 'A', 'Penting untuk pertumbuhan, penglihatan, dan kesehatan kulit serta rambut. juga mencegah penyakit Merophtalmia (penyakit mata dimana selaput ikat mata menjadi kering)', '500 UI', 'Susu, margarine, telur, hati dan ginjal, sayuran hijau dan kuning'),
(2, 'B1', 'Penting untuk sistem syaraf dan fungsi jantung. kekurangan vitamin ini akan mengakibatkan gejala tidak ada nafsu makan, sukar buang air besar, susah tidur dan gelisah. mencegah beri-beri', '1,5 mg', 'Padi-padian, roti dan tepung, ikan, daging tanpa lemak, hati, susu dan ayam'),
(3, 'B2', 'Penting untuk kulit yang sehat, dan untuk pertumbuhan jaringan tubuh. mencegah kepekaan mata terhadap cahaya', '1,7 mg', 'Roti, padi-padian, sayuran hijau yang berdaun, daging tanpa lemak, hati, ragi kering, susu, telur'),
(4, 'B6', 'Penting untuk kesehatan gigi, dan gus, juga penting untuk sel-sel darah merah dan sistem syaraf', '2,0 mg', 'Padi-padian, gandum, sayuran, ragi kering, daging dan pisang'),
(5, 'B12', 'Mencegah anemia dan membantu kesehatan sistem syaraf dan pertumbuhan yang baik bagi anak-anak', '6 ug', 'Semua daging binatang, hati, limpa, susu, ikan laut'),
(6, 'C', 'Penting untuk kesehatan gigi, gusi dan tulang. membentuk sel-sel tubuh dan pembuluh darah. mencegah kudisan', '60 mg', 'Vitamin C dalam bentuk sari buah, buah-buahan asam dan sari buah, kol, sayur hijau dan kentang'),
(7, 'D', 'Baik untuk gigi dan tulang. membantu tubuh menggunakan kalsium dan phospor. mencegah rakhitis', '400 IU', 'Susu, minyak ikan, ikan salmon, ikan tuna dan kuning telur'),
(8, 'E', 'Baik untuk fungsi darah, dan mencegah kebanyakan asam lemak', '30 IU', 'Minyak sayur, gandum, padi-padian, dan lettuce'),
(9, 'Bc', 'Mencegah beberapa bentuk anemi dan membantu cara kerja usus', '0,4 mg', 'Sayuran berdaun berwarna hijau, ragi makanan dan daging'),
(11, 'H', 'Penting bagi metabolisme karbohidrat , lemak dan protein', '0,3 mg', 'Kuning telur, sayuran hijau, susu, hati, ginjal'),
(12, 'B5', 'Penting bagi penggunaan tubuh akan karbohidrat, lemak dan protein', '10 mg', 'Semua makanan dari tumbuh-tumbuhan dan daging'),
(14, 'B3', 'Padi-padian yang bergizi tinggi, roti, telur, daging tanpa lemak, hati dan ragi kering', '20 mg ji', 'Padi-padian yang bergizi tinggi, roti, telur, daging tanpa lemak, hati dan ragi kering');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `administrator`
--
ALTER TABLE `administrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `floraindo`
--
ALTER TABLE `floraindo`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `istilahbiologi`
--
ALTER TABLE `istilahbiologi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `istilahpentingmedis`
--
ALTER TABLE `istilahpentingmedis`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `vitamin`
--
ALTER TABLE `vitamin`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `administrator`
--
ALTER TABLE `administrator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=711;
--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `floraindo`
--
ALTER TABLE `floraindo`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=183;
--
-- AUTO_INCREMENT for table `istilahbiologi`
--
ALTER TABLE `istilahbiologi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
--
-- AUTO_INCREMENT for table `istilahpentingmedis`
--
ALTER TABLE `istilahpentingmedis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `vitamin`
--
ALTER TABLE `vitamin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
