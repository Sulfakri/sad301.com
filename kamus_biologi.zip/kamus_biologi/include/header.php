<nav class="navbar navbar-default navbar-fixed-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">
            <?php if (isset($_SESSION["administrator_id"])) { 
                echo "<p class='text-danger'>Kamus Biologi v1.0</p>"; } else {
                echo "<p clas='text-primary'>Kamus Biologi v1.0</p>";
                }
            ?>
        </a>
    </div>
    <div class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="side-menu">
                <li><a href="index.php"><i class="glyphicon glyphicon-home"></i>  Home</a></li>
                <li><a href=""><i class="glyphicon glyphicon-tasks"></i>  Lainnya<span class="fa arrow"></span></a>
                    <ul class="nav nav-third-level">
                        <li><a href="index.php?flora-indonesia"><i class="fa fa-leaf fa-fw" aria-hidden="true"></i>  Flora Indonesia Berkhasiat Sebagai Obat</a></li>
                        <li><a href="index.php?istilah-medis"><i class="fa fa-book fa-fw" aria-hidden="true"></i>  Istilah Penting Medis</a></li>
                        <li><a href="index.php?vitamin"><i class="fa fa-beer fa-fw" aria-hidden="true"></i>  Vitamin</a></li>
                    </ul>
                </li>
                <li><a href="index.php?contact"><i class="glyphicon glyphicon-envelope"></i> Contact Us</a></li>
                <li><a href="#" data-toggle="modal" data-target="#about"><i class="glyphicon glyphicon-info-sign"></i> About</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="modal fade" id="about" tabindex="-1" role="" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Tentang Aplikasi</h4>
      </div>
      <div class="modal-body" style="text-align: justify;">
        <div class="col-sm-3 about-top-left"> 
            <img class="img-rounded" width="110px" height="110px" src="assets/icon.png" >
        </div>
        <div class="col-lg-9 about-top-right">
            <p class="text-muted">Aplikasi Kamus Biologi ini dibuat sebagai bahan referensi bagi para ilmuwan, dosen, mahasiswa ataupun praktisi yang berkecimpung dalam ilmu Biologi.</p>
        </div>
        <p class="text-muted">Selain itu terdapat fitur lain di dalam Kamus ini yang dapat digunakan sebagai sumber referensi. Kami berharap dengan kehadiran Kamus ini dapat membantu dalam mempelajari Biologi dan lebih memahami istilah-istilah Biologi yang sebelumnya belum dipahami</p>
        <ul class="list-group">
          <li class="list-group-item list-group-item-info">Aplikasi ini dibuat oleh :</li>
          <li class="list-group-item">Sulfakri Sapruddin</li>
          <li class="list-group-item">Mahasiswa D3 Teknik Komputer</li>
          <li class="list-group-item">AMIK Catur Sakti Kendari</li>
          <li class="list-group-item">Penelitian Tugas Akhir</li>
          <li class="list-group-item">Email: sulfakrisapruddin@gmail.com</li>
        </ul>
      </div>
      <!-- <div class="modal-footer">
        <p class="text-danger pull-left"><strong>&copy; 2016, Copyrigths <a href="#">Kamus Biologi</a>. All Rights Reserved</strong></p>
      </div> -->
    </div>
  </div>
</div>