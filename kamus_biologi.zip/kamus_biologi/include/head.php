<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="keywword" content="Kamus Biologi, Aplikasi Web Responsif, Istilah Biologi, Istilah Kesehatan, Istilah Flora" />
    <title>Kamus Biologi</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet" />
    <link href="css/sb-admin.css" rel="stylesheet" />
    <link href="assets/icon.png" type="image/x-icon" rel="Shortcut Icon" />
    <script src="js/jquery-1.10.2.js"></script>
    <script src="js/jquery-1.11.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
	<script src="js/up.js"></script>
</head>