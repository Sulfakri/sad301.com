<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/plugins/metisMenu/jquery.metisMenu.js"></script>
<script src="js/sb-admin.js"></script>

<footer>
	<p class="text-success"><a href="#">&nbsp;Kamus Biologi</a> Copyrigt &copy; 2016. | Design by : Sulfakri. All Rights Reserved. </p>
</footer>
