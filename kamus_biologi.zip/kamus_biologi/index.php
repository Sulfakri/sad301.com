<?php
ob_start();
session_start();

require_once("config.php");

?>
<!DOCTYPE html>
<html>
<style type="text/css">
    .animated {
      -webkit-animation-duration: 1s;
      animation-duration: 1s;
      -webkit-animation-fill-mode: both;
      animation-fill-mode: both;
    }

    @-webkit-keyframes fadeInUp {
      0% {
        opacity: 0;
        -webkit-transform: translateY(10px);
        transform: translateY(10px);
      }
      100% {
        opacity: 1;
        -webkit-transform: translateY(0);
        transform: translateY(0);
      }
    }

    @keyframes fadeInUp {
      0% {
        opacity: 0;
        -webkit-transform: translateY(10px);
        -ms-transform: translateY(10px);
        transform: translateY(10px);
      }
      100% {
        opacity: 1;
        -webkit-transform: translateY(0);
        -ms-transform: translateY(0);
        transform: translateY(0);
      }
    }

    .fadeInUp {
      -webkit-animation-name: fadeInUp;
      animation-name: fadeInUp;
    }
        </style>
<?php require_once("include/head.php") ?>
<body>
    <div id="wrapper">
        <?php require_once("include/header.php") ?>
        <div id="page-wrapper">
            <?php
            if (isset($_GET["search-result"])) require_once("page/home/search-result.php");
			else if (isset($_GET["flora-indonesia"])) require_once("page/home/flora-indonesia.php");
			else if (isset($_GET["istilah-medis"])) require_once("page/home/istilah-medis.php");
            else if (isset($_GET["vitamin"])) require_once("page/home/vitamin.php");
			else if (isset($_GET["contact"])) require_once("page/home/contact.php");
            else if (isset($_GET["search-flora"])) require_once("page/home/search-flora.php");
            else if (isset($_GET["search-medis"])) require_once("page/home/search-medis.php");
            else if (isset($_GET["cat-a"])) require_once("page/indeks/cat-a.php");
            else if (isset($_GET["cat-b"])) require_once("page/indeks/cat-b.php");
            else if (isset($_GET["cat-c"])) require_once("page/indeks/cat-c.php");
            else if (isset($_GET["cat-d"])) require_once("page/indeks/cat-d.php");
            else if (isset($_GET["cat-e"])) require_once("page/indeks/cat-e.php");
            else if (isset($_GET["cat-f"])) require_once("page/indeks/cat-f.php");
            else if (isset($_GET["cat-g"])) require_once("page/indeks/cat-g.php");
            else if (isset($_GET["cat-h"])) require_once("page/indeks/cat-h.php");
            else if (isset($_GET["cat-i"])) require_once("page/indeks/cat-i.php");
            else if (isset($_GET["cat-j"])) require_once("page/indeks/cat-j.php");
            else if (isset($_GET["cat-k"])) require_once("page/indeks/cat-k.php");
            else if (isset($_GET["cat-l"])) require_once("page/indeks/cat-l.php");
            else if (isset($_GET["cat-m"])) require_once("page/indeks/cat-m.php");
            else if (isset($_GET["cat-n"])) require_once("page/indeks/cat-n.php");
            else if (isset($_GET["cat-o"])) require_once("page/indeks/cat-o.php");
            else if (isset($_GET["cat-p"])) require_once("page/indeks/cat-p.php");
            else if (isset($_GET["cat-q"])) require_once("page/indeks/cat-q.php");
            else if (isset($_GET["cat-r"])) require_once("page/indeks/cat-r.php");
            else if (isset($_GET["cat-s"])) require_once("page/indeks/cat-s.php");
            else if (isset($_GET["cat-t"])) require_once("page/indeks/cat-t.php");
            else if (isset($_GET["cat-u"])) require_once("page/indeks/cat-u.php");
            else if (isset($_GET["cat-v"])) require_once("page/indeks/cat-v.php");
            else if (isset($_GET["cat-w"])) require_once("page/indeks/cat-w.php");
            else if (isset($_GET["cat-x"])) require_once("page/indeks/cat-x.php");
            else if (isset($_GET["cat-y"])) require_once("page/indeks/cat-y.php");
            else if (isset($_GET["cat-z"])) require_once("page/indeks/cat-z.php");
            else require_once("page/home/index.php");
            ?>
        </div>
    </div>
    <?php require_once("include/footer.php") ?>
</body>
</html>
<?php 
mysql_close($connection);
ob_end_flush(); 
?>