<?php

global $connection;

$connection = mysql_connect("localhost","root","") or die(mysql_error());
mysql_select_db("kamus_biologi", $connection) or die(mysql_error());
?> 