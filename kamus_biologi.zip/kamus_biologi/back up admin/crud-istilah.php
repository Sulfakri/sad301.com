<?php

if (empty($_SESSION["administrator_id"])) header("location:login.php"); 

if (isset($_POST["submit_save_istilah"])) {
    $nama = mysql_real_escape_string(trim(ucwords($_POST["nama"])));
    $detail = mysql_real_escape_string(trim($_POST["detail"]));
    $gambar = mysql_real_escape_string(trim($_POST["gambar"]));

    mysql_query("INSERT INTO istilahbiologi VALUES ('','$nama','$detail','$gambar');") or die(mysql_error());

    header("location:index.php?crud-istilah");
}
$sql_istilah = mysql_query("SELECT * FROM istilahbiologi ORDER BY nama ASC;") or die(mysql_error());
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Crud data istilah by <?php echo $_SESSION["administrator_username"]?></h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Input Data Istilah
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form role="form" action="" method="post">
                            <div class="form-group">
                                <label>Istilah</label>
                                <input class="form-control" required="required" type="text" name="nama" />
                            </div>
                            <div class="form-group">
                                <label>Detail</label>
                                <input class="form-control" required="required"type="text" name="detail" />
                            </div>
                            <button type="submit" name="submit_save_istilah" class="btn btn-success">Save</button>
                            <button type="reset" class="btn btn-warning">Reset</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                List Data 
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Detail</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (mysql_num_rows($sql_istilah) > 0) { ?>
                            <?php $no = 1 ?>  
                                <?php while ($row_istilah = mysql_fetch_array($sql_istilah)) { ?>
                                    <?php 
                                        if (($no % 2) == 0) {
                                            $class_background = "odd";
                                        } else {
                                            $class_background = "even";
                                        }
                                        
                                    ?>
                                    <tr class="<?php echo $class_background ?> gradeA">
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $row_istilah["nama"]; ?></td>
                                        <td><?php echo $row_istilah["detail"]; ?></td>
                                        <td class="center">
                                        <a href="index.php?administrator-update=<?php echo $row_istilah["id"]; ?>" class="btn btn-primary btn-xs" type="button">Update</a></td>
                                        <td class="center">
                                        <a href="index.php?administrator-delete=<?php echo $row_istilah["id"]; ?>" class="btn btn-primary btn-xs" type="button">Delete</a>
                                        </td>
                                    </tr>
                                <?php $no++ ?>
                            <?php } ?>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
