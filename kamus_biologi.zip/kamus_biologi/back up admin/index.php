<?php
if (!empty($_SESSION["administrator_id"])) header("location:login.php"); 

ob_start();
session_start();

require_once("config.php");

?>
<!DOCTYPE html>
<html>
<?php require_once("../include/head.php") ?>
<body>
    <div id="wrapper">
        <?php require_once("../include/header.php") ?>
        <div id="page-wrapper">
        <div class="col-lg-12">
        <h2 class="page-header">Selamat Datang &raquo; <?php echo $_SESSION["administrator_username"] ?></h2>
        </div>
            <?php 
            if (isset($_GET["administrator"])) {include("../administrator/index.php");}
            else if (isset($_GET["administrator-update"])) require_once("../administrator/update.php");
            else if (isset($_GET["crud-istilah"])) require_once("../administrator/crud-istilah.php");
            else if (isset($_GET["administrator-delete"])) require_once("../administrator/delete.php");
            else require_once("../page/home/index.php");
            ?>
        </div>
    </div>
    <?php require_once("../include/footer.php") ?>
</body>
</html>
<?php 
ob_end_flush(); 
?>
