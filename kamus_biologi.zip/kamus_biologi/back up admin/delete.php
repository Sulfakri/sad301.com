<?php
if (isset($_GET["administrator-delete"])) {
	$id = (int)mysql_real_escape_string(trim($_GET["administrator-delete"]));
	mysql_query("DELETE FROM istilahbiologi WHERE id = '$id';") or die (mysql_error());
}
header("location:index.php?crud-istilah");