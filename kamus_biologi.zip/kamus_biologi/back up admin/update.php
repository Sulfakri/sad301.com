<?php
if (isset($_POST["submit_update_istilah"])) {
    $id_istilah = mysql_real_escape_string(trim($_POST["id_istilah"]));
    $nama = mysql_escape_string(trim($_POST["nama"]));
    $detail = mysql_escape_string(trim($_POST["detail"]));

    mysql_query("UPDATE istilahbiologi SET nama='$nama' , detail='$detail' 
    			WHERE id='$id_istilah';") or die(mysql_error());
    
    header("location:index.php?crud-istilah");
}

$id = (int)mysql_real_escape_string(trim($_GET["administrator-update"]));

$sql_update_istilah = mysql_query("SELECT * FROM istilahbiologi WHERE id = '$id';") or die(mysql_error());

if (mysql_num_rows($sql_update_istilah)==0) header("location:index.php?administrator");
$row_update_istilah = mysql_fetch_array($sql_update_istilah);
$sql_update = mysql_query("SELECT * FROM istilahbiologi ORDER BY nama ASC;") or die(mysql_error());

if (isset($_POST["cancel_update"])) header("location:index.php?crud-istilah");
?>
<div class="row">
    <div class="col-lg-12">
        <h3 class="page-header">Update &raquo; Istilah</h3>
    </div>
</div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
                Input Data
            </div>
            <div class="panel-body">
                <div class="row">
                    <div class="col-lg-12">
                        <form role="form" action="" method="post">
                            <div class="form-group">
                                <label>Nama</label>
                                <input class="form-control" type="text" name="nama" value="<?php echo $row_update_istilah["nama"] ?>" />
                            </div>
                            <div class="form-group">
                                <label>Detail</label>
                                <input class="form-control" type="text" name="detail" value="<?php echo $row_update_istilah["detail"] ?>"/>
                            </div>
                            <button type="submit" name="submit_update_istilah" class="btn btn-success">Update</button>
                            <button type="submit" name="cancel_update" class="btn btn-warning">Batal</button>
                            <input type="hidden" name="id_istilah" value="<?php echo $row_update_istilah["id"] ?>"></input>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="panel panel-default">
            <div class="panel-heading">
                List Data
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Nama</th>
                                <th>Detail</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php if (mysql_num_rows($sql_update) > 0) { ?>
                            <?php $no = 1 ?>  
                                <?php while ($row_detail = mysql_fetch_array($sql_update)) { ?>
                                    <?php 
                                        if (($no % 2) == 0) {
                                            $class_background = "odd";
                                        } else {
                                            $class_background = "even";
                                        }
                                        
                                    ?>
                                    <tr class="<?php echo $class_background ?> gradeA">
                                        <td><?php echo $no; ?></td>
                                        <td><?php echo $row_detail["nama"]; ?></td>
                                        <td><?php echo $row_detail["detail"]; ?></td>
                                        <td class="center"><a href="index.php?administrator-update=<?php echo $row_detail["id"]; ?>" class="btn btn-primary btn-xs" type="button">Update</a></td>
                                        <td class="center"><a href="index.php?administrator-delete=<?php echo $row_detail["id"]; ?>" class="btn btn-primary btn-xs" type="button">Delete</a></td>
                                    </tr>
                                <?php $no++; ?>
                            <?php } ?>
                        <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>