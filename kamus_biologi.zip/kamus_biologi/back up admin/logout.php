<?php
session_start();

$_SESSION["administrator_id"] = "";
$_SESSION["administrator_username"] = "";

unset($_SESSION["administrator_id"]);
unset($_SESSION["administrator_username"]);

session_unset();
session_destroy();

header("location:index.php");
 
?>