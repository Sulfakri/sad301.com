<?php 
if (isset($_POST["submit_cari"])) {
    $keyword = mysql_escape_string(strip_tags(addslashes($_POST["istilah"])));
} 
$sql_hasil = mysql_query("SELECT * FROM istilahbiologi WHERE nama LIKE '%$keyword%';") or die(mysql_error());
?>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header"><p class="text-primary">Selamat Belajar</p></h3>
    </div>
</div>
    <div class="col-lg-12">
        <div class="panel panel-primary">
            <div class="panel-heading">
                Pencarian
            </div>
            <div class="panel-body">
                <div class="row">
                        <div class="col-lg-12">
                            <form role="form" action="index.php?search-result" method="post">
                                <div class="form-group input-group has-success">
                                    <input class="form-control" required="required" placeholder="Istilah Biologi" type="text" name="istilah" />
                                    <span class="input-group-addon"></span>
                                </div>
                                <button type="submit" name="submit_cari"  id="search" data-loading-text="Loading..." class="btn btn-success" autocomplete="off"><i class="fa fa-search"></i> Cari</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </form>
                        </div>
                </div>
            </div>
        </div>
        <?php if (mysql_num_rows($sql_hasil) > 0) { ?>
            <?php while ($row = mysql_fetch_array($sql_hasil)) { ?>
                        <div class="well well-sm">
                            <p><strong><?php echo $row["nama"]; ?></strong> ~<?php echo $row["detail"]; ?></p>
                        </div>
            <?php } ?>
        <?php } else { ?>
            <div class="alert alert-danger fade in">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                <span class="fa fa-info-circle fa-fw"></span>Istilah tidak ditemukan 
            </div>
        <?php } ?>
    </div>
<script>
    $('#search').on('click', function () {
    var $btn = $(this).button('loading')
    //
    $btn.button('reset')
  })
</script>