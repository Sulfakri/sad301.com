<?php
if (isset($_POST["kirim_pesan"])) {
    $nama = mysql_escape_string(trim(ucwords($_POST["nama"])));
    $email = mysql_escape_string(trim($_POST["email"]));
    $isipesan = mysql_escape_string(trim($_POST["isipesan"]));
    date_default_timezone_set("Asia/Jakarta");
    $datetime = date("d-m-Y G:i:s");
    $sql_in = mysql_query("INSERT INTO contact VALUES ('','$nama','$email','$isipesan','$datetime');") or die(mysql_error());
    header("location:index.php?contact=$nama&success-comment#success");
}
?>

<div class="row animated fadeInUp">
    <div class="col-lg-12">
      <div class="fade in">
        <p style="font-size:18px;" class="teks-success page-header">Anda dapat menghubungi kami dengan mengirimi kami pesan. Kritik, saran, dan masukan yang positif akan sangat kami hargai.</p>
        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#contactus"><span class="glyphicon glyphicon-envelope"></span> Kirim Pesan</button>
      </div>
    </div>
    <?php if (isset($_GET['success-comment'])) { ?>
    &nbsp;
<div class="col-md-12">
    <div class="alert alert-success fade in">
        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
        <blockquote>Pesan Anda sedang kami review. Terimakasih atas waktunya</blockquote>
    </div> 
</div>
<?php } ?>
</div>
<div class="modal fade" id="contactus" tabindex="-1" role="dialog" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title">Pesan</h4>
      </div>
      <div class="modal-body">
        <form action="" method="post" enctype="multipart/form-data">
          <div class="form-group">
            <label class="control-label">Nama:</label>
            <input type="text" class="form-control" name="nama" placeholder="Nama Anda" required>
          </div>
          <div class="form-group">
            <label class="control-label">Email:</label>
            <input type="email" class="form-control" name="email" placeholder="example@mail.com" required>
          </div>
          <div class="form-group">
            <label for="message-text" class="control-label">Pesan:</label>
            <textarea class="form-control" type="text" name="isipesan" placeholder="Isi Pesan Anda" required></textarea>
          </div>
            <button type="submit" class="btn btn-primary btn-primary" name="kirim_pesan"><i class="fa fa-share" aria-hidden="true"></i> Kirim</button>
        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-power-off" aria-hidden="true"></i> Close</button>
      </div>
    </div>
  </div>
</div>