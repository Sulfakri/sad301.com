<?php $lihat_medis = mysql_query("SELECT * FROM istilahpentingmedis ORDER BY namaistilah ASC") or die(mysql_error()); ?>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header">Istilah Penting Medis</h3>
    </div>
</div>
<div class="row animated fadeInUp">
  <div class="col-lg-12">
    <p style="font-size:16px">Dunia medis merupakan dunia yang memiliki banyak istilah untuk mengungkapkan penyakit atau obat. Yang dimana rata - rata bahasa yang dipakai sulit di pahami masyarakat awam. Oleh karena itu agar tidak keliru atau  terjebak dari kesalahan obat atau yang lainnya, kami memberikan beberapa istilah medis yang biasa digunakan dimasyarakat dan sering dipakai oleh petugas medis.</p>
  </div>
</div>
    <button class="btn btn-info" type="button" data-toggle="collapse" data-target="#daftarMedis" aria-expanded="false" aria-controls="collapseExample">Lihat Daftar</button>
    <button type="button" data-toggle="modal" data-target="#cariMedis" class="btn btn-primary">Cari Istilah Medis</button>

<!--modal cari flora-->
<div class="modal fade" tabindex="-1" aria-hidden="true" id="cariMedis" role="dialog">
    <div class="modal-dialog modal-sm">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><p class="text-danger">Cari Istilah Medis</p></h4>
            </div>
                <div class="modal-body">
                    <form action="index.php?search-medis" method="post" enctype="multipart/form-data">
                      <div class="form-group input-group has-danger">
                        <input type="text" class="form-control" name="namaMedis" placeholder="Nama Medis" required><span class="input-group-addon"><i class="fa fa-search fa-fw"></i></span>
                      </div>
                        <button type="submit" class="btn btn-primary btn-primary" name="cari_medis"><i class="fa fa-search"></i> Cari</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
        </div>
    </div>
</div>
<!--daftar medis-->

<div class="row animated fadeInUp">
<br>
    <div class="col-lg-10 col-md-8 collapse" id="daftarMedis">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <strong class="text-primary">Daftar Istilah Medis</strong>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-condensed table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama Istilah Medis</th>
                        <th>Detail</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($lihat_medis) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_medis = mysql_fetch_array($lihat_medis)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "warning";
                           } else {
                              $class_background = "danger";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?>">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_medis["namaistilah"]; ?></td>
                        <td><?php echo $row_medis["detailistilah"]; ?></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>
    <div class="row animated fadeInUp">
        <div class="col-lg-6">
            <?php if (mysql_num_rows($lihat_medis) > 0) { ?>
            <?php while ($row_cari_medis = mysql_fetch_array($lihat_medis)) { ?>
            <div class="alert alert-success fade-in">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                <span class="fa fa-info-circle fa-fw"></span>
                <p><strong><?php echo $row_cari_medis["namaistilah"]?></strong> : <?php echo $row_cari_medis["detailistilah"]?>.</p>
            </div>
            <?php } ?>
            <?php } else { ?>
            <div class="alert alert-danger fade in">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                <span class="fa fa-info-circle fa-fw"></span>Istilah yang dimaksud tidak tersedia 
            </div>
            <?php } ?>
    </div>
</div>