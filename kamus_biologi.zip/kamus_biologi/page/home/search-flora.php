<?php 
if (isset($_POST["cari_flora"])) {
    $keyword = mysql_escape_string(strip_tags(addslashes($_POST["namaFlora"])));
} 
$sql_hasil_flora = mysql_query("SELECT * FROM floraindo WHERE nama_tumbuhan LIKE '%$keyword%';") or die(mysql_error());
?>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header"><p class="text-primary">Nama Flora</p></h3>
    </div>
</div>
<div class="row animated fadeInUp">
    <div class="col-lg-10">
        <div class="panel panel-info">
            <div class="panel-heading">
                <p class="text-danger"><strong>Hasil Pencarian</strong></p>
            </div>
        </div>
        <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#carilagi"><i class="glyphicon glyphicon-search" aria-hidden="true"></i> Cari lagi</button><br><br>
                  <?php if (mysql_num_rows($sql_hasil_flora)>0) { ?>
                      <?php while ($row_hasil = mysql_fetch_array($sql_hasil_flora)) { ?>
                          <div class="well well-sm">
                        <p class="text-default" style="font-size:16px">
                            <strong><?php echo $row_hasil['nama_tumbuhan']?></strong>. Khasiatnya : <?php echo $row_hasil['khasiat']?>. Unsur obat yaitu pada bagian : <?php echo $row_hasil['unsur_obat']?>  
                        </p>
                          </div>
                      <?php } ?>
                  <?php } else { ?>
                    <div class="alert alert-danger fade in">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                        <span class="fa fa-info-circle fa-fw"></span> Nama Flora tidak ditemukan 
                    </div>
                    <?php } ?>
    </div>

        <div class="modal fade" tabindex="-1" aria-hidden="true" id="carilagi" role="dialog">
            <div class="modal-dialog">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><p class="text-success">Cari Nama Flora</p></h4>
                        </div>
                        <div class="modal-body">
                            <form action="#" method="post" enctype="multipart/form-data">
                                <div class="form-group input-group has-success">
                                    <input type="text" class="form-control input-group-addon" name="namaFlora" placeholder="Nama Tumbuhan" required><span class="input-group-addon"><i class="fa fa-search fa-fw"></i></span>
                                </div>
                                    <button type="submit" class="btn btn-primary" name="cari_flora"><i class="fa fa-search"></i> Cari</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
</div>
        