<?php $lihat_vitamin = mysql_query("SELECT * FROM vitamin ORDER BY namavitamin ASC") or die(mysql_error()); ?>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header">Vitamin</h3>
    </div>
</div>
<div class="row animated fadeInUp">
  <div class="col-lg-12">
    <p style="font-size:16px">Vitamin menjadi kebutuhan yang sangat penting untuk proses metabolisme dalam tubuh. Beberapa sumber makanan berikut ini menjadi sumber vitamin.</p>
  </div>
</div>
    <button class="btn btn-info" type="button" data-toggle="collapse" data-target="#daftarVitamin" aria-expanded="false" aria-controls="collapseExample">Daftar Vitamin</button>

<!--daftar flora-->
<div class="row animated fadeInUp">
&nbsp;
    <div class="col-lg-12 collapse" id="daftarVitamin">
        <div class="panel panel-info">
            <div class="panel-heading">
                <strong class="text-primary">Daftar Vitamin</strong>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>VIT</th>
                        <th>Fungsi</th>
                        <th>Kadar</th>
                        <th>Sumber Makanan</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($lihat_vitamin) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_vitamin = mysql_fetch_array($lihat_vitamin)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "info";
                           } else {
                              $class_background = "success";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?>">
                        <td><?php echo $no; ?></td>
                        <td><strong><?php echo $row_vitamin["namavitamin"]; ?></strong></td>
                        <td><?php echo $row_vitamin["fungsi"]; ?></td>
                        <td><?php echo $row_vitamin["kadar"]; ?></td>
                        <td><?php echo $row_vitamin["sumbermakanan"]; ?></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>