<?php 
if (isset($_POST["cari_medis"])) {
    $keyword = mysql_escape_string(strip_tags(addslashes($_POST["namaMedis"])));
} 
$sql_hasil_medis = mysql_query("SELECT * FROM istilahpentingmedis WHERE namaistilah LIKE '%$keyword%';") or die(mysql_error());
?>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header"><p class="text-primary">Nama Istilah Medis</p></h3>
    </div>
</div>
<div class="row animated fadeInUp">
    <div class="col-lg-10">
        <div class="panel panel-danger">
            <div class="panel-heading">
                <p class="text-danger"><strong>Hasil Pencarian</strong></p>
            </div>
        </div>
                  <?php if (mysql_num_rows($sql_hasil_medis)>0) { ?>
                      <?php while ($row_hasil = mysql_fetch_array($sql_hasil_medis)) { ?>
                          <div class="well well-sm">
                        <p class="text-default" style="font-size:16px">
                            <strong><?php echo $row_hasil['namaistilah']?></strong> : <?php echo $row_hasil['detailistilah']?>.
                        </p>
                          </div>
                      <?php } ?>
                  <?php } else { ?>
                    <div class="alert alert-danger fade in">
                        <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                        <span class="fa fa-info-circle fa-fw"></span>Istilah tidak ditemukan 
                    </div>
                    <?php } ?>
            
<!--        cari lagi -->
        <button type="button" class="btn btn-primary btn-sm pull-right" data-toggle="modal" data-target="#carilagi"><i class="glyphicon glyphicon-search" aria-hidden="true"></i> Cari lagi</button><br><br>
</div>

        <div class="modal fade" tabindex="-1" aria-hidden="true" id="carilagi" role="dialog">
            <div class="modal-dialog">
                <div class="modal-dialog modal-sm">
                    <div class="modal-content">
                        <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                        <h4 class="modal-title"><p class="text-success">Cari Istilah Medis</p></h4>
                        </div>
                        <div class="modal-body">
                            <form action="#" method="post" enctype="multipart/form-data">
                                <div class="form-group input-group has-danger">
                                    <input type="text" class="form-control input-group-addon" name="namaMedis" placeholder="Nama Istilah Medis" required><span class="input-group-addon"><i class="fa fa-search fa-fw"></i></span>
                                </div>
                                    <button type="submit" class="btn btn-primary" name="cari_medis"><i class="fa fa-search"></i> Cari</button>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
            </div>
</div>
        