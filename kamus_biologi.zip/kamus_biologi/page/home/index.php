<?php
    $istilah = mysql_query("SELECT * FROM istilahbiologi ORDER BY nama ASC") or die(mysql_error());
?>
   <!-- indeks huruf -->
<div class="text-center">
<nav aria-label="Page navigation">
  <ul class="pagination animated fadeInUp">
    <li><a href="index.php?cat-a"><span aria-hidden="true">A</span></a></li>
    <li><a href="index.php?cat-b">B</a></li>
    <li><a href="index.php?cat-c">C</a></li>
    <li><a href="index.php?cat-d">D</a></li>
    <li><a href="index.php?cat-e">E</a></li>
    <li><a href="index.php?cat-f">F</a></li>
    <li><a href="index.php?cat-g">G</a></li>
    <li><a href="index.php?cat-h">H</a></li>
    <li><a href="index.php?cat-i">I</a></li>
    <li><a href="index.php?cat-j">J</a></li>
    <li><a href="index.php?cat-k">K</a></li>
    <li><a href="index.php?cat-l">L</a></li>
    <li><a href="index.php?cat-m">M</a></li>
    <li><a href="index.php?cat-n">N</a></li>
    <li><a href="index.php?cat-o">O</a></li>
    <li><a href="index.php?cat-p">P</a></li>
    <li><a href="index.php?cat-q">Q</a></li>
    <li><a href="index.php?cat-r">R</a></li>
    <li><a href="index.php?cat-s">S</a></li>
    <li><a href="index.php?cat-t">T</a></li>
    <li><a href="index.php?cat-u">U</a></li>
    <li><a href="index.php?cat-v">V</a></li>
    <li><a href="index.php?cat-w">W</a></li>
    <li><a href="index.php?cat-x">X</a></li>
    <li><a href="index.php?cat-y">Y</a></li>
    <li><a href="index.php?cat-z"><span aria-hidden="true">Z</span></a></li>
  </ul>
</nav>
</div>
<!-- end indeks -->

<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header">Selamat Belajar</h3>
    </div>
</div>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
   <div class="panel panel-info">
            <div class="panel-heading">
                Pencarian
            </div>
            <div class="panel-body">
                <div class="row">
                        <div class="col-lg-12">
                            <form role="form" action="index.php?search-result" method="post">
                                <div class="form-group has-success">
                                    <input class="form-control" required="required" placeholder="Istilah Biologi" name="istilah" />
                                </div>
                                <button type="submit" name="submit_cari" class="btn btn-success"><i class="fa fa-search"></i> Cari</button>
                                <button type="reset" class="btn btn-danger">Reset</button>
                            </form>
                        </div>
                </div>
            </div>
    </div>
    </div>
    <br>
</div>