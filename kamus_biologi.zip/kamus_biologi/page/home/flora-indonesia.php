<?php $lihat_flora = mysql_query("SELECT * FROM floraindo ORDER BY nama_tumbuhan ASC") or die(mysql_error()); ?>
<div class="row animated fadeInUp">
    <div class="col-lg-12">
        <h3 class="page-header">Flora Indonesia yang Berkhasiat Sebagai Obat</h3>
    </div>
</div>
<div class="row animated fadeInUp">
	<div class="col-lg-12">
		<p style="font-size:16px">Kekayaan alam Indonesia sangatlah luas, bersyukurlah kita sebagai warga Negara Indonesia dapat menikmati berkah yang berlimpah ini, salah satunya adalah kekayaan alam flora.</p><p class="text-default" style="font-size:16px">Berikut ini kami sajikan beberapa flora di Indonesia yang berkhasiat sebagai obat, sekaligus dapat menambah wawasan pengetahuan kita semua.</p>
	</div>
</div>
    <button class="btn btn-primary" type="button" data-toggle="collapse" data-target="#daftarFlora" aria-expanded="false" aria-controls="collapseExample">Lihat Daftar</button>
    <button type="button" data-toggle="modal" data-target="#cariFlora" class="btn btn-success">Cari Nama Tumbuhan</button>
<!--modal cari flora-->
<div class="modal fade" tabindex="-1" aria-hidden="true" id="cariFlora" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal">&times;</button>
                <h4 class="modal-title"><p class="text-danger">Cari Nama Flora</p></h4>
            </div>
                <div class="modal-body">
                    <form action="index.php?search-flora" method="post" enctype="multipart/form-data">
                      <div class="form-group input-group has-error">
                        <input type="text" class="form-control" name="namaFlora" placeholder="Nama Tumbuhan" required><span class="input-group-addon"><i class="fa fa-search fa-fw"></i></span>
                      </div>
                        <button type="submit" class="btn btn-primary btn-primary" name="cari_flora"><i class="fa fa-search"></i> Cari</button>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                </div>
        </div>
    </div>
</div>
<!--daftar flora-->
<div class="row animated fadeInUp">
<br>
    <div class="col-lg-8 collapse " id="daftarFlora">
        <div class="panel panel-primary">
            <div class="panel-heading">
                <strong class="text-default">Daftar Flora yang Berkhasiat Sebagai Obat</strong>
            </div>
            <div class="panel-body">
                <div class="table-responsive">
                  <table class="table table-striped table-condensed table-hover" id="dataTables-example">
                    <thead>
                      <tr>
                        <th>No</th>
                        <th>Nama Tumbuhan</th>
                        <th>Unsur Obat</th>
                        <th>Khasiat</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php if (mysql_num_rows($lihat_flora) > 0) { ?>
                      <?php $no = 1 ?>
                      <?php while ($row_flora = mysql_fetch_array($lihat_flora)) { ?>
                        <?php 
                          if (($no % 2) == 0) {
                              $class_background = "info";
                           } else {
                              $class_background = "success";
                           }         
                        ?>
                      <tr class="<?php echo $class_background ?>">
                        <td><?php echo $no; ?></td>
                        <td><?php echo $row_flora["nama_tumbuhan"]; ?></td>
                        <td><?php echo $row_flora["unsur_obat"]; ?></td>
                        <td><?php echo $row_flora["khasiat"]; ?></td>
                      </tr>
                      <?php $no++ ?>
                      <?php } ?>
                      <?php } ?>
                    </tbody>
                  </table>
                </div>
            </div>
        </div>
    </div>
</div>
    <div class="row animated fadeInUp">
        <div class="col-lg-6">
            <?php if (mysql_num_rows($lihat_flora) > 0) { ?>
            <?php while ($row_cari_flora = mysql_fetch_array($lihat_flora)) { ?>
            <div class="alert alert-success fade-in">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                <span class="fa fa-info-circle fa-fw"></span>
                <p><strong><?php echo $row_cari_flora ["nama_tumbuhan"]?></strong>, berkasiat sebagai <?php echo $row_cari_flora["khasiat"]?>. Unsur obat yaitu pada bagian <?php echo $row_cari_flora["unsur_obat"]?></p>
            </div>
            <?php } ?>
            <?php } else { ?>
            <div class="alert alert-danger fade in">
                <button aria-hidden="true" data-dismiss="alert" class="close" type="button">&times;</button>
                <span class="fa fa-info-circle fa-fw"></span>Tumbuhan yang dimaksud tidak tersedia 
            </div>
            <?php } ?>
    </div>
</div>