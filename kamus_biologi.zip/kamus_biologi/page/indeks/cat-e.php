<div class="text-center">
<nav aria-label="Page navigation">
  <ul class="pagination animated fadeInUp">
    <li><a href="index.php?cat-a"><span aria-hidden="true">A</span></a></li>
    <li><a href="index.php?cat-b">B</a></li>
    <li><a href="index.php?cat-c">C</a></li>
    <li><a href="index.php?cat-d">D</a></li>
    <li><a href="index.php?cat-e">E</a></li>
    <li><a href="index.php?cat-f">F</a></li>
    <li><a href="index.php?cat-g">G</a></li>
    <li><a href="index.php?cat-h">H</a></li>
    <li><a href="index.php?cat-i">I</a></li>
    <li><a href="index.php?cat-j">J</a></li>
    <li><a href="index.php?cat-k">K</a></li>
    <li><a href="index.php?cat-l">L</a></li>
    <li><a href="index.php?cat-m">M</a></li>
    <li><a href="index.php?cat-n">N</a></li>
    <li><a href="index.php?cat-o">O</a></li>
    <li><a href="index.php?cat-p">P</a></li>
    <li><a href="index.php?cat-q">Q</a></li>
    <li><a href="index.php?cat-r">R</a></li>
    <li><a href="index.php?cat-s">S</a></li>
    <li><a href="index.php?cat-t">T</a></li>
    <li><a href="index.php?cat-u">U</a></li>
    <li><a href="index.php?cat-v">V</a></li>
    <li><a href="index.php?cat-w">W</a></li>
    <li><a href="index.php?cat-x">X</a></li>
    <li><a href="index.php?cat-y">Y</a></li>
    <li><a href="index.php?cat-z"><span aria-hidden="true">Z</span></a></li>
  </ul>
</nav>
</div>
<!-- end indeks -->
<?php $show = mysql_query("SELECT * FROM istilahbiologi WHERE cat_huruf='E';")?>
<div class="row animated fadeInUp">
    <div class="col-lg-12" style="">
            <div class="panel panel-primary">
                <div class="panel-heading">
                    Istilah Biologi indeks : E <p class="pull-right">Show Total :<b> <?php echo mysql_num_rows($show)?></b> Istilah</p> 
                </div>
                
                <div class="panel-body">
                    <div class="table-responsive">
                        <table class="table table-stripped table-bordered table-condensed table-hover">
                        <thead>
                            <th>No</th>
                            <th>Nama Istilah Biologi</th>
                            <th>Detail</th>
                        </thead>
                        <tbody>
                            <?php if (mysql_num_rows($show)>0) { ?>
                            <?php $no = 1?>
                            <?php while ($row_show = mysql_fetch_array($show)) { ?>
                                <?php
                                if (($no % 2)==0) {
                                    $class_bgd = "odd";
                                } else { 
                                    $class_bgd = "even";
                                } ?>
                            <tr class="<?php echo $class_bgd ?>">
                                <td><?php echo $no;?></td>
                                <td><?php echo $row_show["nama"];?></td>
                                <td><?php echo $row_show["detail"];?></td>
                            </tr><?php $no++ ?>

                            <?php } ?>

                            <?php } else { ?>
                                <tr>
                                    <td colspan="12" align="center" class="alert alert-danger">Maaf Istilah Belum ada</td>
                                </tr>    
                            <?php } ?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
        
    </div>
</div>